// src/app/api/billing/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { createCustomerPortalSession } from '@/lib/stripe'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.redirect(new URL('/auth/signin', req.url))

  const user = await prisma.user.findUnique({ where: { id: (session.user as any).id } })
  if (!user?.stripeCustomerId) return NextResponse.redirect(new URL('/pricing', req.url))

  const portal = await createCustomerPortalSession(
    user.stripeCustomerId,
    `${process.env.NEXT_PUBLIC_APP_URL}/dashboard`
  )

  return NextResponse.redirect(portal.url)
}
