// src/app/api/checkout/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { createCheckoutSession, type PlanKey } from '@/lib/stripe'

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { planKey } = await req.json()
  if (!planKey) {
    return NextResponse.json({ error: 'planKey required' }, { status: 400 })
  }

  const baseUrl = process.env.NEXT_PUBLIC_APP_URL!

  try {
    const checkout = await createCheckoutSession({
      planKey: planKey as PlanKey,
      userId:    (session.user as any).id,
      userEmail: session.user.email!,
      successUrl: `${baseUrl}/dashboard?success=1&plan=${planKey}`,
      cancelUrl:  `${baseUrl}/pricing?canceled=1`,
    })

    return NextResponse.json({ url: checkout.url })
  } catch (err: any) {
    console.error('Checkout error:', err)
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
