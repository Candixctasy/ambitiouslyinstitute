// src/app/api/intake/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const schema = z.object({
  skinType:        z.enum(['NORMAL','DRY','OILY','COMBINATION','SENSITIVE','MATURE']),
  conditions:      z.array(z.string()).default([]),
  concerns:        z.array(z.string()).default([]),
  sensitivities:   z.array(z.string()).default([]),
  currentProducts: z.string().optional(),
  medications:     z.string().optional(),
  pregnant:        z.boolean().default(false),
  lifestyle:       z.string().optional(),
  ageRange:        z.string().optional(),
  fitzpatrick:     z.number().min(1).max(6).optional().nullable(),
})

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const body   = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) return NextResponse.json({ error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 })

    const intake = await prisma.intake.create({
      data: {
        userId:          (session.user as any).id,
        ...parsed.data,
        fitzpatrick:     parsed.data.fitzpatrick ?? null,
      },
    })

    return NextResponse.json({ intakeId: intake.id })
  } catch (err: any) {
    console.error('Intake error:', err)
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
