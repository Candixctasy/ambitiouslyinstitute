// src/app/api/analyze/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import Anthropic from '@anthropic-ai/sdk'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! })

const ANALYSIS_PROMPT = `You are C-Ai, an expert skin analysis system trained in clinical esthetics and cosmetic science with over 20 years of professional expertise.

Analyze the provided skin image and return a structured JSON assessment. Be precise, educational, and evidence-based. Never make medical claims.

Return ONLY valid JSON in this exact format:
{
  "overallCondition": "brief 1-sentence assessment",
  "fitzpatrickEstimate": 1-6,
  "skinType": "NORMAL|DRY|OILY|COMBINATION|SENSITIVE|MATURE",
  "hydrationLevel": "LOW|MODERATE|HIGH",
  "oilinessLevel": "LOW|MODERATE|HIGH",
  "visibleConditions": ["list of visible conditions: acne, rosacea, hyperpigmentation, etc."],
  "concerns": ["list of concerns: fine_lines, enlarged_pores, dullness, uneven_texture, etc."],
  "barrierIntegrity": "COMPROMISED|FAIR|GOOD|EXCELLENT",
  "urgentFlags": ["any conditions that warrant professional/medical referral"],
  "ingredientRecommendations": {
    "prioritize": ["top 5 ingredient categories to include"],
    "avoid": ["ingredient categories to avoid based on visible skin state"]
  },
  "educationalNote": "2-3 sentences explaining what the skin is showing and why — educational, not medical",
  "confidence": 0.0-1.0
}`

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const { imageBase64, mimeType = 'image/jpeg', intakeId } = await req.json()

    if (!imageBase64) {
      return NextResponse.json({ error: 'Image required' }, { status: 400 })
    }

    // Consent check — intakeId must exist and belong to user
    if (intakeId) {
      const intake = await prisma.intake.findFirst({
        where: { id: intakeId, userId: (session.user as any).id },
      })
      if (!intake) {
        return NextResponse.json({ error: 'Invalid intake session' }, { status: 403 })
      }
    }

    const response = await anthropic.messages.create({
      model:      'claude-opus-4-5',
      max_tokens: 1024,
      messages: [{
        role: 'user',
        content: [
          {
            type:   'image',
            source: { type: 'base64', media_type: mimeType, data: imageBase64 },
          },
          { type: 'text', text: ANALYSIS_PROMPT },
        ],
      }],
    })

    const raw = response.content[0].type === 'text' ? response.content[0].text : ''

    // Parse and validate
    let analysis: Record<string, unknown>
    try {
      const cleaned = raw.replace(/```json|```/g, '').trim()
      analysis = JSON.parse(cleaned)
    } catch {
      console.error('Analysis parse error:', raw)
      return NextResponse.json({ error: 'Analysis parsing failed' }, { status: 500 })
    }

    // Save to DB if intakeId provided
    if (intakeId) {
      await prisma.intake.update({
        where: { id: intakeId },
        data: {
          analysisRaw:   JSON.stringify(analysis),
          analysisScore: analysis as any,
          skinType:      (analysis.skinType as string) as any,
          conditions:    (analysis.visibleConditions as string[]) ?? [],
          concerns:      (analysis.concerns as string[]) ?? [],
        },
      })
    }

    return NextResponse.json({ analysis })
  } catch (err: any) {
    console.error('Analyze error:', err)
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
