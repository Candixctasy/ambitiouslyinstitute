// src/app/api/webhooks/stripe/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { headers } from 'next/headers'
import { stripe } from '@/lib/stripe'
import { prisma } from '@/lib/prisma'
import type { Plan, SubscriptionStatus } from '@prisma/client'

export async function POST(req: NextRequest) {
  const body      = await req.text()
  const signature = headers().get('stripe-signature')!

  let event: ReturnType<typeof stripe.webhooks.constructEvent>

  try {
    event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET!)
  } catch (err: any) {
    console.error('Webhook signature verification failed:', err.message)
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })
  }

  try {
    switch (event.type) {

      // ── ONE-TIME PAYMENT ─────────────────────────────────────
      case 'checkout.session.completed': {
        const session = event.data.object as any
        const { userId, planKey } = session.metadata ?? {}
        if (!userId || !planKey) break

        if (session.mode === 'payment') {
          // Grant course access or report credit
          await prisma.order.create({
            data: {
              userId,
              stripePaymentId: session.payment_intent,
              product:  planKey,
              amount:   session.amount_total,
              status:   'COMPLETED',
            },
          })

          // Promote to PRO role for EBOS purchases
          if (planKey.startsWith('EBOS')) {
            await prisma.user.update({
              where: { id: userId },
              data:  { role: 'PRO' },
            })
          }
        }
        break
      }

      // ── SUBSCRIPTION CREATED / RENEWED ───────────────────────
      case 'customer.subscription.created':
      case 'customer.subscription.updated': {
        const sub     = event.data.object as any
        const custId  = sub.customer as string
        const user    = await prisma.user.findFirst({ where: { stripeCustomerId: custId } })
        if (!user) break

        const planKey = (sub.metadata?.planKey ?? '') as Plan

        await prisma.subscription.upsert({
          where:  { stripeSubscriptionId: sub.id },
          create: {
            userId:               user.id,
            stripeSubscriptionId: sub.id,
            stripePriceId:        sub.items.data[0].price.id,
            plan:                 planKey,
            status:               mapStatus(sub.status),
            currentPeriodEnd:     new Date(sub.current_period_end * 1000),
          },
          update: {
            status:           mapStatus(sub.status),
            currentPeriodEnd: new Date(sub.current_period_end * 1000),
            cancelAtPeriodEnd: sub.cancel_at_period_end,
          },
        })

        // Upgrade user role based on plan
        const role = planKey?.startsWith('PRO') ? 'PRO' : 'CONSUMER'
        await prisma.user.update({ where: { id: user.id }, data: { role } })
        break
      }

      // ── SUBSCRIPTION CANCELLED ───────────────────────────────
      case 'customer.subscription.deleted': {
        const sub    = event.data.object as any
        const custId = sub.customer as string
        const user   = await prisma.user.findFirst({ where: { stripeCustomerId: custId } })
        if (!user) break

        await prisma.subscription.updateMany({
          where:  { stripeSubscriptionId: sub.id },
          data:   { status: 'CANCELED' },
        })

        // Downgrade role
        await prisma.user.update({ where: { id: user.id }, data: { role: 'CONSUMER' } })
        break
      }

      // ── PAYMENT FAILED ────────────────────────────────────────
      case 'invoice.payment_failed': {
        const inv    = event.data.object as any
        const custId = inv.customer as string
        const user   = await prisma.user.findFirst({ where: { stripeCustomerId: custId } })
        if (!user) break

        await prisma.subscription.updateMany({
          where: { userId: user.id, status: 'ACTIVE' },
          data:  { status: 'PAST_DUE' },
        })
        // TODO: send dunning email via Resend
        break
      }
    }

    return NextResponse.json({ received: true })
  } catch (err: any) {
    console.error('Webhook handler error:', err)
    return NextResponse.json({ error: 'Internal error' }, { status: 500 })
  }
}

function mapStatus(s: string): SubscriptionStatus {
  const map: Record<string, SubscriptionStatus> = {
    active:   'ACTIVE',
    past_due: 'PAST_DUE',
    canceled: 'CANCELED',
    trialing: 'TRIALING',
    incomplete: 'INCOMPLETE',
  }
  return map[s] ?? 'INCOMPLETE'
}
