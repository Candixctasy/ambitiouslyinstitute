// src/app/api/formula/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { buildFormula, type IntakeData } from '@/lib/formulation-engine'
import { generateConsumerReport, generateLabPack } from '@/lib/pdf-generator'
import type { ProductType } from '@prisma/client'

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const userId = (session.user as any).id
  const role   = (session.user as any).role

  try {
    const body = await req.json()
    const { intakeId, productType, cosmos = false, mode = 'CONSUMER' } = body

    // PRO mode requires PRO or ADMIN role
    if (mode === 'PRO' && !['PRO', 'ADMIN'].includes(role)) {
      return NextResponse.json({ error: 'Pro subscription required' }, { status: 403 })
    }

    // Load intake
    const intake = await prisma.intake.findFirst({
      where: { id: intakeId, userId },
    })
    if (!intake) {
      return NextResponse.json({ error: 'Intake not found' }, { status: 404 })
    }

    // Build formula
    const intakeData: IntakeData = {
      skinType:      intake.skinType,
      conditions:    intake.conditions,
      concerns:      intake.concerns,
      sensitivities: intake.sensitivities,
      pregnant:      intake.pregnant,
      cosmos,
      routineLength: (intake.lifestyle as any) ?? 'moderate',
      budget:        'mid',
      productType:   productType as ProductType,
      mode,
    }

    const formula = buildFormula(intakeData)

    if (formula.ingredients.length === 0 && formula.warnings.length > 0) {
      return NextResponse.json({ formula, blocked: true })
    }

    // Generate PDF
    let pdfBytes: Uint8Array
    let pdfType: 'consumer' | 'lab' = 'consumer'

    if (mode === 'PRO') {
      pdfBytes = await generateLabPack(formula, session.user.name ?? 'Professional', 'Client Reference', new Date())
      pdfType  = 'lab'
    } else {
      pdfBytes = await generateConsumerReport(formula, session.user.name ?? 'Client', new Date())
    }

    // Convert to base64 for inline delivery (production would upload to S3/Supabase)
    const pdfBase64 = Buffer.from(pdfBytes).toString('base64')

    // Save formula request
    const formulaRequest = await prisma.formulaRequest.create({
      data: {
        userId,
        intakeId,
        productType:  productType as ProductType,
        mode:         mode as any,
        formulaJson:  formula as any,
        spfBlocked:   formula.warnings.some(w => w.includes('SPF')),
        cosmos,
      },
    })

    return NextResponse.json({
      formulaId:  formulaRequest.id,
      formula,
      pdfBase64,
      pdfType,
    })
  } catch (err: any) {
    console.error('Formula error:', err)
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
