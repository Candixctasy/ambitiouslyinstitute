// src/app/auth/signin/page.tsx
'use client'
import { useState } from 'react'
import { signIn } from 'next-auth/react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { Loader2, Mail, Lock, ArrowRight } from 'lucide-react'

export default function SignInPage() {
  const router      = useRouter()
  const params      = useSearchParams()
  const callbackUrl = params.get('callbackUrl') || '/dashboard'

  const [mode, setMode]       = useState<'signin' | 'magic'>('signin')
  const [email, setEmail]     = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError]     = useState('')
  const [sent, setSent]       = useState(false)

  async function handleCredentials(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true); setError('')
    const res = await signIn('credentials', { email, password, redirect: false, callbackUrl })
    setLoading(false)
    if (res?.error) { setError('Invalid email or password'); return }
    router.push(callbackUrl)
  }

  async function handleMagicLink(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true); setError('')
    const res = await signIn('email', { email, redirect: false, callbackUrl })
    setLoading(false)
    if (res?.error) { setError('Could not send link. Try again.'); return }
    setSent(true)
  }

  return (
    <main className="min-h-screen bg-ink flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-10">
          <Link href="/" className="font-display text-2xl text-cream">
            Ambitiously <span className="text-gold">Institute</span>
          </Link>
          <p className="text-cream/40 text-sm mt-2">Sign in to your account</p>
        </div>

        <div className="bg-obsidian border border-gold/10 p-8">
          {/* Toggle */}
          <div className="flex mb-8 border-b border-gold/10">
            {(['signin', 'magic'] as const).map(m => (
              <button key={m} onClick={() => setMode(m)}
                className={`flex-1 pb-3 text-xs uppercase tracking-widest transition-colors ${
                  mode === m ? 'text-gold border-b-2 border-gold -mb-px' : 'text-cream/30 hover:text-cream/60'
                }`}
              >
                {m === 'signin' ? 'Password' : 'Magic Link'}
              </button>
            ))}
          </div>

          {sent ? (
            <div className="text-center py-8">
              <Mail size={32} className="text-gold mx-auto mb-4" />
              <p className="text-cream font-display text-xl mb-2">Check your email</p>
              <p className="text-cream/50 text-sm">We sent a sign-in link to <strong>{email}</strong></p>
            </div>
          ) : (
            <form onSubmit={mode === 'signin' ? handleCredentials : handleMagicLink} className="space-y-5">
              <div>
                <label className="input-label">Email</label>
                <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                  className="input-field" placeholder="you@example.com" required />
              </div>

              {mode === 'signin' && (
                <div>
                  <label className="input-label">Password</label>
                  <input type="password" value={password} onChange={e => setPassword(e.target.value)}
                    className="input-field" placeholder="••••••••" required />
                </div>
              )}

              {error && <p className="text-sm text-alert">{error}</p>}

              <button type="submit" disabled={loading}
                className="btn-gold w-full justify-center disabled:opacity-50">
                {loading ? <Loader2 size={16} className="animate-spin" /> : null}
                {loading ? 'Please wait…' : mode === 'signin' ? 'Sign In' : 'Send Magic Link'}
                {!loading && <ArrowRight size={14} />}
              </button>
            </form>
          )}

          <p className="text-center text-xs text-cream/30 mt-6">
            No account?{' '}
            <Link href="/auth/register" className="text-gold hover:text-gold-light transition-colors">Create one free</Link>
          </p>
        </div>
      </div>
    </main>
  )
}
