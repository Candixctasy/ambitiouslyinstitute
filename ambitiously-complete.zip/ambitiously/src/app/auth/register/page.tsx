// src/app/auth/register/page.tsx
'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { ArrowRight, Loader2 } from 'lucide-react'

export default function RegisterPage() {
  const router = useRouter()
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'CONSUMER' })
  const [loading, setLoading] = useState(false)
  const [error, setError]     = useState('')

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true); setError('')
    const res  = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })
    const data = await res.json()
    setLoading(false)
    if (!res.ok) { setError(data.error || 'Registration failed'); return }
    router.push('/auth/signin?registered=1')
  }

  return (
    <main className="min-h-screen bg-ink flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-10">
          <Link href="/" className="font-display text-2xl text-cream">
            Ambitiously <span className="text-gold">Institute</span>
          </Link>
          <p className="text-cream/40 text-sm mt-2">Create your account</p>
        </div>

        <div className="bg-obsidian border border-gold/10 p-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="input-label">Full Name</label>
              <input className="input-field" placeholder="Your name" required
                value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
            </div>
            <div>
              <label className="input-label">Email</label>
              <input type="email" className="input-field" placeholder="you@example.com" required
                value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
            </div>
            <div>
              <label className="input-label">Password</label>
              <input type="password" className="input-field" placeholder="Min 8 characters" minLength={8} required
                value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} />
            </div>
            <div>
              <label className="input-label">I am a…</label>
              <select className="input-field"
                value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value }))}>
                <option value="CONSUMER">Consumer — personal skincare</option>
                <option value="PRO">Professional — esthetician / MUA / medspa</option>
              </select>
            </div>

            {error && <p className="text-sm text-alert">{error}</p>}

            <button type="submit" disabled={loading} className="btn-gold w-full justify-center disabled:opacity-50">
              {loading ? <Loader2 size={16} className="animate-spin" /> : null}
              {loading ? 'Creating account…' : 'Create Account'}
              {!loading && <ArrowRight size={14} />}
            </button>
          </form>

          <p className="text-center text-xs text-cream/30 mt-6">
            Have an account?{' '}
            <Link href="/auth/signin" className="text-gold hover:text-gold-light transition-colors">Sign in</Link>
          </p>
        </div>

        <p className="text-center text-xs text-cream/20 mt-6 leading-relaxed">
          By creating an account you agree to our Terms of Service and Privacy Policy.
          This platform provides educational and cosmetic information only.
        </p>
      </div>
    </main>
  )
}
