// src/app/dashboard/results/page.tsx
'use client'
import { useEffect, useState } from 'react'
import { useSearchParams } from 'next/navigation'
import { Download, AlertTriangle, CheckCircle, Loader2, FlaskConical, ArrowRight } from 'lucide-react'
import Link from 'next/link'

export default function ResultsPage() {
  const params      = useSearchParams()
  const intakeId    = params.get('intakeId')
  const productType = params.get('productType') || 'SERUM'
  const cosmos      = params.get('cosmos') === 'true'

  const [data, setData]       = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError]     = useState('')

  useEffect(() => {
    if (!intakeId) return
    fetch('/api/formula', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ intakeId, productType, cosmos }),
    })
      .then(r => r.json())
      .then(d => { if (d.error) throw new Error(d.error); setData(d) })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false))
  }, [intakeId, productType, cosmos])

  function downloadPDF() {
    if (!data?.pdfBase64) return
    const bytes = Uint8Array.from(atob(data.pdfBase64), c => c.charCodeAt(0))
    const blob  = new Blob([bytes], { type: 'application/pdf' })
    const url   = URL.createObjectURL(blob)
    const a     = document.createElement('a')
    a.href      = url
    a.download  = `cai-formula-${Date.now()}.pdf`
    a.click()
    URL.revokeObjectURL(url)
  }

  if (loading) return (
    <div className="min-h-screen bg-ink flex items-center justify-center">
      <div className="text-center">
        <Loader2 size={32} className="text-gold animate-spin mx-auto mb-4" />
        <p className="font-display text-xl text-cream">Building your formula…</p>
        <p className="text-cream/40 text-sm mt-2">C-Ai is analysing your skin profile</p>
      </div>
    </div>
  )

  if (error) return (
    <div className="min-h-screen bg-ink flex items-center justify-center px-6">
      <div className="max-w-md text-center">
        <AlertTriangle size={32} className="text-alert mx-auto mb-4" />
        <p className="font-display text-xl text-cream mb-2">Something went wrong</p>
        <p className="text-cream/50 text-sm mb-6">{error}</p>
        <Link href="/start" className="btn-gold">Try Again</Link>
      </div>
    </div>
  )

  const { formula } = data ?? {}
  if (!formula) return null

  return (
    <main className="min-h-screen bg-ink pt-24 pb-32">
      <div className="max-w-3xl mx-auto px-6">

        {/* Header */}
        <div className="mb-10">
          <p className="label-tag mb-3">Your C-Ai Formula</p>
          <h1 className="font-display text-4xl text-cream mb-2">{formula.productName}</h1>
          <p className="text-cream/40 text-sm">{formula.ingredients.length} ingredients — {formula.totalPercentage}% total</p>
        </div>

        {/* Warnings */}
        {formula.warnings?.length > 0 && (
          <div className="mb-8 space-y-2">
            {formula.warnings.map((w: string, i: number) => (
              <div key={i} className="flex items-start gap-2 bg-amber-500/10 border border-amber-500/20 p-3">
                <AlertTriangle size={14} className="text-amber-400 mt-0.5 shrink-0" />
                <p className="text-xs text-amber-300">{w}</p>
              </div>
            ))}
          </div>
        )}

        {/* Cert paths */}
        {formula.certPaths?.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-8">
            {formula.certPaths.map((c: string) => (
              <span key={c} className="flex items-center gap-1 text-xs bg-teal/10 border border-teal/20 text-teal-light px-3 py-1">
                <CheckCircle size={10} /> {c}
              </span>
            ))}
          </div>
        )}

        {/* Ingredient Table */}
        <div className="bg-obsidian border border-gold/10 mb-8">
          <div className="border-b border-gold/10 px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FlaskConical size={16} className="text-gold" />
              <h2 className="font-display text-lg text-cream">Formula Breakdown</h2>
            </div>
            <div className="flex gap-4 text-xs">
              <span className="flex items-center gap-1"><span className="w-2 h-2 bg-teal rounded-full inline-block" /> Essential</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 bg-gold rounded-full inline-block" /> Beneficial</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 bg-charcoal rounded-full inline-block" /> Optional</span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gold/5">
                  <th className="text-left px-6 py-3 text-xs text-cream/30 uppercase tracking-wider font-normal">Ingredient</th>
                  <th className="text-left px-3 py-3 text-xs text-cream/30 uppercase tracking-wider font-normal hidden md:table-cell">INCI</th>
                  <th className="text-left px-3 py-3 text-xs text-cream/30 uppercase tracking-wider font-normal">Phase</th>
                  <th className="text-right px-6 py-3 text-xs text-cream/30 uppercase tracking-wider font-normal">%</th>
                </tr>
              </thead>
              <tbody>
                {formula.ingredients.map((ing: any, i: number) => (
                  <tr key={i} className={`border-b border-gold/5 ${i % 2 === 0 ? '' : 'bg-charcoal/20'}`}>
                    <td className="px-6 py-3">
                      <div className="flex items-center gap-2">
                        <span className={`w-2 h-2 rounded-full shrink-0 ${
                          ing.tier === 'ESSENTIAL' ? 'bg-teal' :
                          ing.tier === 'BENEFICIAL' ? 'bg-gold' : 'bg-charcoal'
                        }`} />
                        <div>
                          <p className="text-cream text-sm">{ing.commonName}</p>
                          <p className="text-cream/30 text-xs hidden md:block">{ing.rationale}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-3 text-cream/40 text-xs hidden md:table-cell">{ing.inci}</td>
                    <td className="px-3 py-3">
                      <span className="text-xs text-teal-light">Phase {ing.phase}</span>
                    </td>
                    <td className="px-6 py-3 text-right font-mono text-gold font-medium">{ing.percentage}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Routines */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {[
            { label: 'Morning Routine', steps: formula.amRoutine, color: 'gold' },
            { label: 'Evening Routine', steps: formula.pmRoutine, color: 'teal' },
          ].map(r => (
            <div key={r.label} className="bg-obsidian border border-gold/10 p-6">
              <h3 className={`font-display text-lg mb-4 ${r.color === 'gold' ? 'text-gold' : 'text-teal-light'}`}>{r.label}</h3>
              <ol className="space-y-2">
                {r.steps?.map((s: string, i: number) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-cream/60">
                    <span className={`text-xs font-mono mt-0.5 shrink-0 ${r.color === 'gold' ? 'text-gold' : 'text-teal-light'}`}>{String(i+1).padStart(2,'0')}</span>
                    {s}
                  </li>
                ))}
              </ol>
            </div>
          ))}
        </div>

        {/* Disclaimer */}
        <div className="bg-charcoal border border-gold/10 p-4 mb-8">
          <p className="text-xs text-cream/40 leading-relaxed">{formula.consumerNote}</p>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap gap-4">
          <button onClick={downloadPDF} className="btn-gold">
            <Download size={16} /> Download PDF Report
          </button>
          <Link href="/start" className="btn-outline">
            Build Another Formula <ArrowRight size={14} />
          </Link>
          <Link href="/dashboard" className="btn-ghost">
            Go to Dashboard
          </Link>
        </div>
      </div>
    </main>
  )
}
