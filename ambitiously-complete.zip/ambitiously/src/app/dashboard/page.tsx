// src/app/dashboard/page.tsx
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { ArrowRight, FlaskConical, BookOpen, Users, BarChart3, Plus } from 'lucide-react'

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)
  if (!session?.user) redirect('/auth/signin?callbackUrl=/dashboard')

  const userId = (session.user as any).id
  const role   = (session.user as any).role

  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: {
      subscription: true,
      intakes: { orderBy: { createdAt: 'desc' }, take: 5 },
      formulaRequests: { orderBy: { createdAt: 'desc' }, take: 5 },
      clients: { take: 5 },
      orders: { orderBy: { createdAt: 'desc' }, take: 5 },
      courseProgress: { include: { course: true, lessons: true } },
    },
  })

  if (!user) redirect('/auth/signin')

  return (
    <main className="min-h-screen bg-ink pt-24 pb-32">
      <div className="container-lg">

        {/* Header */}
        <div className="flex items-start justify-between mb-12">
          <div>
            <p className="label-tag mb-2">Welcome back</p>
            <h1 className="font-display text-4xl text-cream">
              {user.name ?? 'Your Dashboard'}
            </h1>
            <p className="text-cream/40 text-sm mt-1">
              {role === 'ADMIN' ? 'Administrator' : role === 'PRO' ? 'Professional Account' : 'Consumer Account'}
              {user.subscription && ` · ${user.subscription.plan.replace(/_/g,' ')} · ${user.subscription.status}`}
            </p>
          </div>
          <Link href="/start" className="btn-gold hidden md:flex">
            <Plus size={16} /> New Analysis
          </Link>
        </div>

        {/* Quick stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {[
            { label: 'Analyses', value: user.intakes.length, icon: <FlaskConical size={16} className="text-gold" /> },
            { label: 'Formulas', value: user.formulaRequests.length, icon: <BarChart3 size={16} className="text-teal-light" /> },
            ...(role === 'PRO' || role === 'ADMIN' ? [{ label: 'Clients', value: user.clients.length, icon: <Users size={16} className="text-rose" /> }] : []),
            { label: 'Courses', value: user.courseProgress.length, icon: <BookOpen size={16} className="text-gold-light" /> },
          ].map(stat => (
            <div key={stat.label} className="bg-obsidian border border-gold/10 p-5">
              <div className="flex items-center gap-2 mb-3">{stat.icon}<p className="text-xs text-cream/40 uppercase tracking-widest">{stat.label}</p></div>
              <p className="font-display text-3xl text-cream">{stat.value}</p>
            </div>
          ))}
        </div>

        {/* Main grid */}
        <div className="grid md:grid-cols-3 gap-6">

          {/* Recent formulas */}
          <div className="md:col-span-2 bg-obsidian border border-gold/10 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-display text-xl text-cream">Recent Formulas</h2>
              <Link href="/start" className="text-xs text-gold hover:text-gold-light transition-colors flex items-center gap-1">
                New <ArrowRight size={12} />
              </Link>
            </div>
            {user.formulaRequests.length === 0 ? (
              <div className="text-center py-12 border border-dashed border-gold/10">
                <FlaskConical size={24} className="text-gold/30 mx-auto mb-3" />
                <p className="text-cream/30 text-sm">No formulas yet</p>
                <Link href="/start" className="btn-gold text-xs py-2 px-4 mt-4 inline-flex">Start Analysis</Link>
              </div>
            ) : (
              <div className="space-y-3">
                {user.formulaRequests.map(f => (
                  <div key={f.id} className="flex items-center justify-between border-b border-gold/5 pb-3">
                    <div>
                      <p className="text-sm text-cream">{f.productType.replace(/_/g,' ')}</p>
                      <p className="text-xs text-cream/30">{new Date(f.createdAt).toLocaleDateString('en-CA')}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-[9px] uppercase tracking-wider px-2 py-0.5 ${
                        f.status === 'COMPLETE' ? 'bg-teal/20 text-teal-light' :
                        f.status === 'FAILED'   ? 'bg-alert/20 text-alert' :
                        'bg-gold/10 text-gold'
                      }`}>
                        {f.status}
                      </span>
                      {f.mode === 'PRO' && <span className="text-[9px] bg-rose/20 text-rose px-2 py-0.5 uppercase tracking-wider">Pro</span>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-4">

            {/* Subscription status */}
            <div className="bg-obsidian border border-gold/10 p-5">
              <p className="label-tag mb-3">Your Plan</p>
              {user.subscription ? (
                <div>
                  <p className="font-display text-xl text-cream mb-1">{user.subscription.plan.replace(/_/g,' ')}</p>
                  <p className="text-xs text-cream/40 mb-4">
                    {user.subscription.status === 'ACTIVE' ? `Renews ${new Date(user.subscription.currentPeriodEnd).toLocaleDateString('en-CA')}` : user.subscription.status}
                  </p>
                  <Link href="/api/billing" className="btn-outline text-xs py-2 w-full justify-center">Manage Billing</Link>
                </div>
              ) : (
                <div>
                  <p className="text-cream/40 text-sm mb-4">No active subscription</p>
                  <Link href="/pricing" className="btn-gold text-xs py-2 w-full justify-center">Upgrade</Link>
                </div>
              )}
            </div>

            {/* Quick links */}
            <div className="bg-obsidian border border-gold/10 p-5">
              <p className="label-tag mb-4">Quick Access</p>
              <div className="space-y-2">
                {[
                  { l: 'Start New Analysis', h: '/start' },
                  { l: 'View Academy', h: '/academy' },
                  { l: 'Ingredient Library', h: '/ingredients' },
                  ...(role === 'PRO' || role === 'ADMIN' ? [{ l: 'My Clients', h: '/dashboard/clients' }] : []),
                  ...(role === 'ADMIN' ? [{ l: 'Admin Panel', h: '/admin' }] : []),
                ].map(link => (
                  <Link key={link.l} href={link.h}
                    className="flex items-center justify-between text-sm text-cream/50 hover:text-cream transition-colors py-1">
                    {link.l} <ArrowRight size={12} />
                  </Link>
                ))}
              </div>
            </div>

          </div>
        </div>
      </div>
    </main>
  )
}
