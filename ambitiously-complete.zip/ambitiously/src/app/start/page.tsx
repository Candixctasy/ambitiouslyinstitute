// src/app/start/page.tsx
'use client'
import { useState, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { ArrowRight, ArrowLeft, Upload, Loader2, AlertTriangle, CheckCircle } from 'lucide-react'
import Link from 'next/link'

type Step = 1 | 2 | 3 | 4 | 5 | 6

interface IntakeForm {
  // Step 1 - About you
  name:       string
  ageRange:   string
  fitzpatrick: string
  pregnant:   boolean

  // Step 2 - Skin type
  skinType: string

  // Step 3 - Conditions & concerns
  conditions:  string[]
  concerns:    string[]

  // Step 4 - Sensitivities & history
  sensitivities: string[]
  currentProducts: string
  medications:     string

  // Step 5 - Preferences
  productType:    string
  routineLength:  string
  budget:         string
  cosmos:         boolean

  // Step 6 - Photo
  imageBase64: string
  imagePreview: string
  consent:     boolean
  notMedical:  boolean
}

const INITIAL: IntakeForm = {
  name: '', ageRange: '', fitzpatrick: '', pregnant: false,
  skinType: '',
  conditions: [], concerns: [],
  sensitivities: [], currentProducts: '', medications: '',
  productType: '', routineLength: 'moderate', budget: 'mid', cosmos: false,
  imageBase64: '', imagePreview: '', consent: false, notMedical: false,
}

const CONDITIONS = ['Acne','Rosacea','Hyperpigmentation','Melasma','Eczema','Psoriasis','Perioral dermatitis','Milia']
const CONCERNS   = ['Fine lines','Wrinkles','Firmness','Uneven texture','Enlarged pores','Dullness','Dehydration','Redness','Barrier damage','Dark circles']
const SENSITIVITIES = ['Fragrance','Retinol','Alpha hydroxy acids','Salicylic acid','Essential oils','Niacinamide','Sulfates','Parabens','Silicones','Alcohol']
const SKIN_TYPES = ['Normal','Dry','Oily','Combination','Sensitive','Mature']
const PRODUCT_TYPES = [
  { v: 'CLEANSER', l: 'Cleanser' }, { v: 'TONER', l: 'Toner / Essence' },
  { v: 'SERUM', l: 'Serum' }, { v: 'MOISTURIZER', l: 'Moisturiser' },
  { v: 'EYE_CREAM', l: 'Eye Cream' }, { v: 'MASK', l: 'Mask' },
  { v: 'TREATMENT_OIL', l: 'Treatment Oil' }, { v: 'MIST', l: 'Facial Mist' },
]
const AGE_RANGES = ['Under 18','18–24','25–34','35–44','45–54','55–64','65+']
const FITZ = ['I — Very Fair','II — Fair','III — Medium','IV — Olive','V — Brown','VI — Dark']

export default function StartPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const fileRef = useRef<HTMLInputElement>(null)

  const [step, setStep] = useState<Step>(1)
  const [form, setForm] = useState<IntakeForm>(INITIAL)
  const [loading, setLoading] = useState(false)
  const [analysisResult, setAnalysisResult] = useState<any>(null)
  const [intakeId, setIntakeId] = useState<string | null>(null)
  const [error, setError] = useState('')

  const update = (patch: Partial<IntakeForm>) => setForm(f => ({ ...f, ...patch }))

  function toggleArr(key: 'conditions' | 'concerns' | 'sensitivities', val: string) {
    const arr = form[key]
    update({ [key]: arr.includes(val) ? arr.filter(v => v !== val) : [...arr, val] } as any)
  }

  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    if (file.size > 10 * 1024 * 1024) { setError('Image must be under 10MB'); return }
    const reader = new FileReader()
    reader.onload = ev => {
      const result = ev.target?.result as string
      const base64 = result.split(',')[1]
      update({ imageBase64: base64, imagePreview: result })
    }
    reader.readAsDataURL(file)
  }

  async function createIntake() {
    if (!session) { router.push('/auth/signin?callbackUrl=/start'); return }
    setLoading(true); setError('')
    try {
      const res = await fetch('/api/intake', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          skinType:        form.skinType.toUpperCase().replace(' ','_'),
          conditions:      form.conditions.map(c => c.toLowerCase().replace(' ','_')),
          concerns:        form.concerns.map(c => c.toLowerCase().replace(' ','_')),
          sensitivities:   form.sensitivities.map(c => c.toLowerCase().replace(' ','_')),
          currentProducts: form.currentProducts,
          medications:     form.medications,
          pregnant:        form.pregnant,
          lifestyle:       form.routineLength,
          ageRange:        form.ageRange,
          fitzpatrick:     parseInt(form.fitzpatrick) || null,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setIntakeId(data.intakeId)
      return data.intakeId
    } catch (e: any) {
      setError(e.message)
      return null
    } finally {
      setLoading(false)
    }
  }

  async function runAnalysis(iId: string) {
    if (!form.imageBase64) { setStep(6); return }
    setLoading(true); setError('')
    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: form.imageBase64, mimeType: 'image/jpeg', intakeId: iId }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setAnalysisResult(data.analysis)
      setStep(6)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  async function generateFormula() {
    if (!session) { router.push('/auth/signin?callbackUrl=/start'); return }
    let iId = intakeId
    if (!iId) iId = await createIntake()
    if (!iId) return
    if (form.imageBase64 && !analysisResult) { await runAnalysis(iId); return }
    router.push(`/dashboard/results?intakeId=${iId}&productType=${form.productType}&cosmos=${form.cosmos}`)
  }

  async function handleNext() {
    setError('')
    if (step === 5) {
      const iId = await createIntake()
      if (iId) setStep(6)
      return
    }
    if (step === 6) { await generateFormula(); return }
    setStep((step + 1) as Step)
  }

  const canNext = () => {
    if (step === 1) return form.ageRange && form.skinType === '' ? true : true
    if (step === 2) return form.skinType !== ''
    if (step === 3) return form.concerns.length > 0
    if (step === 4) return true
    if (step === 5) return form.productType !== ''
    if (step === 6) return form.consent && form.notMedical
    return true
  }

  return (
    <main className="min-h-screen bg-ink pt-24 pb-32">
      <div className="max-w-2xl mx-auto px-6">

        {/* Progress */}
        <div className="mb-10">
          <div className="flex justify-between mb-3">
            {[1,2,3,4,5,6].map(n => (
              <div key={n} className={`flex-1 h-1 mx-0.5 transition-colors duration-300 ${n <= step ? 'bg-gold' : 'bg-charcoal'}`} />
            ))}
          </div>
          <p className="text-xs text-cream/30">Step {step} of 6</p>
        </div>

        {/* Steps */}
        {step === 1 && (
          <StepWrapper title="Tell us about yourself">
            <Field label="Your Name">
              <input className="input-field" placeholder="First name" value={form.name}
                onChange={e => update({ name: e.target.value })} />
            </Field>
            <Field label="Age Range">
              <div className="grid grid-cols-3 gap-2">
                {AGE_RANGES.map(a => (
                  <Chip key={a} label={a} active={form.ageRange === a} onClick={() => update({ ageRange: a })} />
                ))}
              </div>
            </Field>
            <Field label="Fitzpatrick Skin Tone">
              <div className="grid grid-cols-2 gap-2">
                {FITZ.map((f, i) => (
                  <Chip key={f} label={f} active={form.fitzpatrick === String(i+1)} onClick={() => update({ fitzpatrick: String(i+1) })} />
                ))}
              </div>
            </Field>
            <label className="flex items-center gap-3 cursor-pointer mt-2">
              <input type="checkbox" checked={form.pregnant} onChange={e => update({ pregnant: e.target.checked })}
                className="w-4 h-4 accent-gold" />
              <span className="text-sm text-cream/70">I am currently pregnant or breastfeeding</span>
            </label>
            {form.pregnant && (
              <div className="flex items-start gap-2 bg-amber-500/10 border border-amber-500/20 p-3 mt-2">
                <AlertTriangle size={14} className="text-amber-400 mt-0.5 shrink-0" />
                <p className="text-xs text-amber-300">Pregnancy mode activated. Retinol, salicylic acid, and other flagged ingredients will be filtered from your formula.</p>
              </div>
            )}
          </StepWrapper>
        )}

        {step === 2 && (
          <StepWrapper title="What is your primary skin type?">
            <p className="text-cream/40 text-sm mb-6">Select the option that best describes your skin on a typical day.</p>
            <div className="grid grid-cols-2 gap-3">
              {SKIN_TYPES.map(t => (
                <Chip key={t} label={t} large active={form.skinType === t.toUpperCase().replace(' ','_')}
                  onClick={() => update({ skinType: t.toUpperCase().replace(' ','_') })} />
              ))}
            </div>
          </StepWrapper>
        )}

        {step === 3 && (
          <StepWrapper title="Conditions & concerns">
            <Field label="Diagnosed / visible conditions (select all that apply)">
              <div className="flex flex-wrap gap-2">
                {CONDITIONS.map(c => (
                  <Chip key={c} label={c} active={form.conditions.includes(c)} onClick={() => toggleArr('conditions', c)} />
                ))}
              </div>
            </Field>
            <Field label="What are your primary skin concerns? (select at least one)">
              <div className="flex flex-wrap gap-2">
                {CONCERNS.map(c => (
                  <Chip key={c} label={c} active={form.concerns.includes(c)} onClick={() => toggleArr('concerns', c)} />
                ))}
              </div>
            </Field>
          </StepWrapper>
        )}

        {step === 4 && (
          <StepWrapper title="Sensitivities & history">
            <p className="text-cream/40 text-sm mb-6">
              Everyone has a sensitivity to something — even if you think you don&apos;t. The system will cross-reference everything you select against your formula.
            </p>
            <Field label="Known sensitivities or ingredients to avoid">
              <div className="flex flex-wrap gap-2">
                {SENSITIVITIES.map(s => (
                  <Chip key={s} label={s} active={form.sensitivities.includes(s)} onClick={() => toggleArr('sensitivities', s)} />
                ))}
              </div>
            </Field>
            <Field label="Current products in use (optional — helps detect conflicts)">
              <textarea className="input-field min-h-[80px] resize-none" placeholder="e.g. tretinoin 0.025%, The Ordinary Glycolic Toner, CeraVe Moisturising Cream…"
                value={form.currentProducts} onChange={e => update({ currentProducts: e.target.value })} />
            </Field>
            <Field label="Prescription medications or topicals (optional)">
              <input className="input-field" placeholder="e.g. Metronidazole gel, oral doxycycline…"
                value={form.medications} onChange={e => update({ medications: e.target.value })} />
            </Field>
          </StepWrapper>
        )}

        {step === 5 && (
          <StepWrapper title="Build your formula">
            <Field label="What product would you like formulated?">
              <div className="grid grid-cols-2 gap-2">
                {PRODUCT_TYPES.map(p => (
                  <Chip key={p.v} label={p.l} active={form.productType === p.v} onClick={() => update({ productType: p.v })} />
                ))}
              </div>
            </Field>
            <Field label="Routine complexity">
              <div className="grid grid-cols-3 gap-2">
                {['minimal','moderate','comprehensive'].map(r => (
                  <Chip key={r} label={r.charAt(0).toUpperCase() + r.slice(1)}
                    active={form.routineLength === r} onClick={() => update({ routineLength: r })} />
                ))}
              </div>
            </Field>
            <Field label="Budget tier">
              <div className="grid grid-cols-3 gap-2">
                {['accessible','mid','luxury'].map(b => (
                  <Chip key={b} label={b.charAt(0).toUpperCase() + b.slice(1)}
                    active={form.budget === b} onClick={() => update({ budget: b })} />
                ))}
              </div>
            </Field>
            <label className="flex items-center gap-3 cursor-pointer mt-2">
              <input type="checkbox" checked={form.cosmos} onChange={e => update({ cosmos: e.target.checked })}
                className="w-4 h-4 accent-gold" />
              <span className="text-sm text-cream/70">Prioritise COSMOS / ECOCERT / organic-certified ingredients</span>
            </label>
          </StepWrapper>
        )}

        {step === 6 && (
          <StepWrapper title="Skin photo analysis">
            <p className="text-cream/40 text-sm mb-6">
              Optional but recommended. Upload a clean, well-lit photo of your face — no makeup. C-Ai performs a visual assessment to refine your formula.
            </p>

            {/* Consent */}
            <div className="space-y-3 mb-6">
              <label className="flex items-start gap-3 cursor-pointer">
                <input type="checkbox" checked={form.consent} onChange={e => update({ consent: e.target.checked })}
                  className="w-4 h-4 mt-0.5 accent-gold" />
                <span className="text-sm text-cream/70">I consent to my photo being processed by AI for skin analysis purposes. My image is not stored after analysis.</span>
              </label>
              <label className="flex items-start gap-3 cursor-pointer">
                <input type="checkbox" checked={form.notMedical} onChange={e => update({ notMedical: e.target.checked })}
                  className="w-4 h-4 mt-0.5 accent-gold" />
                <span className="text-sm text-cream/70">I understand this is an educational and cosmetic tool — not a medical diagnosis. I will consult a healthcare professional for medical concerns.</span>
              </label>
            </div>

            {/* Upload */}
            {form.imagePreview ? (
              <div className="relative mb-4">
                <img src={form.imagePreview} alt="Preview" className="w-full max-h-64 object-cover border border-gold/20" />
                <button onClick={() => update({ imageBase64: '', imagePreview: '' })}
                  className="absolute top-2 right-2 bg-ink/80 text-cream text-xs px-2 py-1 hover:bg-ink transition-colors">
                  Remove
                </button>
              </div>
            ) : (
              <button onClick={() => fileRef.current?.click()}
                className="w-full border border-dashed border-gold/30 hover:border-gold/60 p-12 text-center transition-colors">
                <Upload size={24} className="text-gold/50 mx-auto mb-3" />
                <p className="text-cream/50 text-sm">Click to upload skin photo</p>
                <p className="text-cream/30 text-xs mt-1">JPG, PNG — max 10MB — no makeup, clean lighting</p>
              </button>
            )}
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleFile} />

            {analysisResult && (
              <div className="mt-4 bg-teal/10 border border-teal/20 p-4">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle size={16} className="text-teal-light" />
                  <p className="text-sm text-teal-light font-medium">Analysis complete</p>
                </div>
                <p className="text-cream/60 text-xs leading-relaxed">{analysisResult.educationalNote}</p>
              </div>
            )}
          </StepWrapper>
        )}

        {error && (
          <div className="flex items-center gap-2 bg-alert/10 border border-alert/20 p-3 mb-6">
            <AlertTriangle size={14} className="text-alert shrink-0" />
            <p className="text-sm text-alert">{error}</p>
          </div>
        )}

        {/* Nav */}
        <div className="flex gap-3 mt-8">
          {step > 1 && (
            <button onClick={() => setStep((step - 1) as Step)} className="btn-outline px-5">
              <ArrowLeft size={14} /> Back
            </button>
          )}
          <button onClick={handleNext} disabled={!canNext() || loading}
            className="btn-gold flex-1 justify-center disabled:opacity-40">
            {loading ? <Loader2 size={16} className="animate-spin" /> : null}
            {loading ? 'Processing…' :
              step === 5 ? 'Continue to Photo →' :
              step === 6 ? 'Generate My Formula →' :
              'Continue'}
            {!loading && step < 6 && <ArrowRight size={14} />}
          </button>
        </div>
      </div>
    </main>
  )
}

function StepWrapper({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h1 className="font-display text-3xl text-cream mb-8">{title}</h1>
      <div className="space-y-6">{children}</div>
    </div>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="input-label">{label}</p>
      {children}
    </div>
  )
}

function Chip({ label, active, onClick, large }: { label: string; active: boolean; onClick: () => void; large?: boolean }) {
  return (
    <button onClick={onClick}
      className={`text-xs border px-3 py-2 transition-all duration-150 text-left ${large ? 'py-3' : ''} ${
        active
          ? 'border-gold bg-gold/10 text-gold'
          : 'border-gold/20 text-cream/50 hover:border-gold/40 hover:text-cream/80'
      }`}>
      {label}
    </button>
  )
}
