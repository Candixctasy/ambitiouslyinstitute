// src/app/admin/page.tsx
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { Users, FlaskConical, DollarSign, BarChart3, ArrowRight, ShieldAlert } from 'lucide-react'

export default async function AdminPage() {
  const session = await getServerSession(authOptions)
  if (!session?.user || (session.user as any).role !== 'ADMIN') {
    redirect('/dashboard')
  }

  const [userCount, intakeCount, formulaCount, subCount, recentUsers, recentFormulas] = await Promise.all([
    prisma.user.count(),
    prisma.intake.count(),
    prisma.formulaRequest.count(),
    prisma.subscription.count({ where: { status: 'ACTIVE' } }),
    prisma.user.findMany({ orderBy: { createdAt: 'desc' }, take: 10, include: { subscription: true } }),
    prisma.formulaRequest.findMany({ orderBy: { createdAt: 'desc' }, take: 10, include: { user: true } }),
  ])

  const mrr = await prisma.subscription.findMany({ where: { status: 'ACTIVE' }, select: { plan: true } })
  const mrrTotal = mrr.reduce((acc, s) => {
    const amounts: Record<string, number> = {
      CONSUMER_PRO: 97, PRO_STARTER: 97, PRO_UNLIMITED: 197,
    }
    return acc + (amounts[s.plan] ?? 0)
  }, 0)

  return (
    <main className="min-h-screen bg-ink pt-24 pb-32">
      <div className="container-lg">

        {/* Header */}
        <div className="flex items-center gap-3 mb-10">
          <ShieldAlert size={20} className="text-gold" />
          <div>
            <p className="label-tag">Administrator</p>
            <h1 className="font-display text-3xl text-cream">Platform Dashboard</h1>
          </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {[
            { label: 'Total Users',       value: userCount,    icon: <Users size={16} className="text-gold" />,       sub: 'All registered' },
            { label: 'Active Subs',        value: subCount,     icon: <DollarSign size={16} className="text-teal-light" />, sub: `~$${mrrTotal}/mo MRR` },
            { label: 'Total Intakes',     value: intakeCount,  icon: <FlaskConical size={16} className="text-rose" />, sub: 'Skin analyses' },
            { label: 'Formulas Built',    value: formulaCount, icon: <BarChart3 size={16} className="text-gold-light" />, sub: 'All time' },
          ].map(stat => (
            <div key={stat.label} className="bg-obsidian border border-gold/10 p-5">
              <div className="flex items-center gap-2 mb-3">{stat.icon}<p className="text-xs text-cream/30 uppercase tracking-wider">{stat.label}</p></div>
              <p className="font-display text-4xl text-cream">{stat.value}</p>
              <p className="text-xs text-cream/30 mt-1">{stat.sub}</p>
            </div>
          ))}
        </div>

        {/* Tables */}
        <div className="grid md:grid-cols-2 gap-6">

          {/* Recent Users */}
          <div className="bg-obsidian border border-gold/10 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-display text-xl text-cream">Recent Users</h2>
              <Link href="/admin/users" className="text-xs text-gold flex items-center gap-1">All <ArrowRight size={12} /></Link>
            </div>
            <div className="space-y-3">
              {recentUsers.map(u => (
                <div key={u.id} className="flex items-center justify-between border-b border-gold/5 pb-3">
                  <div>
                    <p className="text-sm text-cream">{u.name ?? u.email}</p>
                    <p className="text-xs text-cream/30">{u.email} · {new Date(u.createdAt).toLocaleDateString('en-CA')}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-[9px] uppercase tracking-wider px-2 py-0.5 ${
                      u.role === 'ADMIN' ? 'bg-rose/20 text-rose' :
                      u.role === 'PRO'   ? 'bg-teal/20 text-teal-light' :
                      'bg-gold/10 text-gold'
                    }`}>{u.role}</span>
                    {u.subscription && (
                      <span className="text-[9px] uppercase tracking-wider bg-teal/20 text-teal-light px-2 py-0.5">
                        {u.subscription.status}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Formulas */}
          <div className="bg-obsidian border border-gold/10 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-display text-xl text-cream">Recent Formulas</h2>
              <Link href="/admin/formulas" className="text-xs text-gold flex items-center gap-1">All <ArrowRight size={12} /></Link>
            </div>
            <div className="space-y-3">
              {recentFormulas.map(f => (
                <div key={f.id} className="flex items-center justify-between border-b border-gold/5 pb-3">
                  <div>
                    <p className="text-sm text-cream">{f.productType.replace(/_/g,' ')} — {f.mode}</p>
                    <p className="text-xs text-cream/30">{f.user.email} · {new Date(f.createdAt).toLocaleDateString('en-CA')}</p>
                  </div>
                  <span className={`text-[9px] uppercase tracking-wider px-2 py-0.5 ${
                    f.status === 'COMPLETE'   ? 'bg-teal/20 text-teal-light' :
                    f.status === 'FAILED'     ? 'bg-alert/20 text-alert' :
                    'bg-gold/10 text-gold'
                  }`}>{f.status}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Admin nav */}
        <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { l: 'Manage Users',      h: '/admin/users' },
            { l: 'Ingredient DB',     h: '/admin/ingredients' },
            { l: 'Course Editor',     h: '/admin/courses' },
            { l: 'Subscriptions',     h: '/admin/subscriptions' },
          ].map(nav => (
            <Link key={nav.l} href={nav.h}
              className="bg-charcoal border border-gold/10 hover:border-gold/30 p-4 text-sm text-cream/60 hover:text-cream transition-all flex items-center justify-between">
              {nav.l} <ArrowRight size={14} />
            </Link>
          ))}
        </div>
      </div>
    </main>
  )
}
