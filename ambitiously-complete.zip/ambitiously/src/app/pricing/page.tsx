// src/app/pricing/page.tsx
'use client'
import { useState } from 'react'
import Link from 'next/link'
import { Check, ArrowRight, Sparkles, FlaskConical, BookOpen } from 'lucide-react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'

const PLANS = {
  consumer: [
    {
      key: 'CONSUMER_BASIC', name: 'Skin Report', price: '$47', period: 'one-time',
      desc: 'One complete personalised formula report with ingredient education.',
      features: ['AI skin analysis','Custom formula (1 product)','AM/PM routine guide','Ingredient education','PDF download','Health Canada compliance check'],
      cta: 'Get My Report', highlight: false,
    },
    {
      key: 'CONSUMER_PRO', name: 'C-Ai Member', price: '$97', period: '/month',
      desc: 'Unlimited analyses, reformulations, and your 2-week check-in protocol.',
      features: ['Everything in Skin Report','Unlimited skin analyses','Multiple product formulas','2-week check-in protocol','Reformulation access','Priority support'],
      cta: 'Join C-Ai', highlight: true,
    },
  ],
  pro: [
    {
      key: 'PRO_STARTER', name: 'Pro Starter', price: '$97', period: '/month',
      desc: 'For estheticians and makeup artists building client product lines.',
      features: ['Up to 10 active clients','Professional Lab Pack PDFs','COSMOS/ECOCERT pathways','Health Canada rules engine','Hotlist caps enforced','Client dashboard'],
      cta: 'Start Pro', highlight: false,
    },
    {
      key: 'PRO_UNLIMITED', name: 'Pro Unlimited', price: '$197', period: '/month',
      desc: 'For medspa operators and brand builders scaling a product line.',
      features: ['Unlimited clients','White-label Lab Pack PDFs','All compliance pathways','NHP pathway guidance','Admin dashboard','Priority queue'],
      cta: 'Scale Now', highlight: true,
    },
  ],
  education: [
    {
      key: 'EBOS_COURSE', name: 'EBOS Program', price: '$497', period: 'one-time',
      desc: 'The complete Executive Beauty Operating System. Six tiers, lifetime access.',
      features: ['6 transformation tiers','40+ video lessons','Consultation architecture','Ingredient intelligence','Certificate of completion','Community access'],
      cta: 'Enrol Now', highlight: false,
    },
    {
      key: 'EBOS_ELITE', name: 'EBOS Elite', price: '$997', period: 'one-time',
      desc: 'Full program plus 3 private coaching sessions with Conrad.',
      features: ['Everything in EBOS Program','3 × 1:1 coaching sessions','Brand strategy review','Formula consultation','Alumni network access','Priority email support'],
      cta: 'Go Elite', highlight: true,
    },
  ],
}

type TabKey = keyof typeof PLANS

function PlanCard({ plan, color }: { plan: typeof PLANS.consumer[0]; color: 'gold'|'teal'|'rose' }) {
  const router = useRouter()
  const { data: session } = useSession()
  const [loading, setLoading] = useState(false)

  async function handleBuy() {
    if (!session) { router.push(`/auth/signin?callbackUrl=/pricing`); return }
    setLoading(true)
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ planKey: plan.key }),
      })
      const data = await res.json()
      if (data.url) window.location.href = data.url
    } finally { setLoading(false) }
  }

  const C = color === 'gold'
    ? { border: plan.highlight ? 'border-gold/50 ring-1 ring-gold/20' : 'border-gold/10', check: 'text-gold', btn: 'btn-gold w-full justify-center' }
    : color === 'teal'
    ? { border: plan.highlight ? 'border-teal/50 ring-1 ring-teal/20' : 'border-teal/10', check: 'text-teal', btn: 'btn-outline w-full justify-center border-teal/40 hover:border-teal hover:text-teal' }
    : { border: plan.highlight ? 'border-rose/50 ring-1 ring-rose/20' : 'border-rose/10', check: 'text-rose', btn: 'btn-outline w-full justify-center border-rose/40 hover:border-rose hover:text-rose' }

  const badgeColor = color === 'gold' ? 'bg-gold text-ink' : color === 'teal' ? 'bg-teal text-cream' : 'bg-rose text-cream'

  return (
    <div className={`relative flex flex-col bg-obsidian border ${C.border} p-8`}>
      {plan.highlight && (
        <span className={`absolute -top-3 left-6 ${badgeColor} text-[10px] font-medium tracking-widest uppercase px-3 py-1`}>
          Most Popular
        </span>
      )}
      <p className="label-tag mb-2">{plan.key.replace('_',' ')}</p>
      <h3 className="font-display text-2xl text-cream mb-1">{plan.name}</h3>
      <div className="flex items-baseline gap-1 mb-3">
        <span className="font-display text-4xl text-gold">{plan.price}</span>
        <span className="text-cream/30 text-sm">{plan.period}</span>
      </div>
      <p className="text-cream/40 text-sm leading-relaxed mb-6">{plan.desc}</p>
      <ul className="space-y-2.5 mb-8 flex-1">
        {plan.features.map(f => (
          <li key={f} className="flex items-start gap-3 text-sm text-cream/70">
            <Check size={13} className={`${C.check} mt-0.5 flex-shrink-0`} />
            {f}
          </li>
        ))}
      </ul>
      <button onClick={handleBuy} disabled={loading} className={C.btn}>
        {loading ? 'Redirecting…' : <>{plan.cta} <ArrowRight size={14}/></>}
      </button>
    </div>
  )
}

export default function PricingPage() {
  const [tab, setTab] = useState<TabKey>('consumer')

  return (
    <main className="min-h-screen bg-ink pt-24 pb-32">
      <div className="container-md text-center mb-16">
        <p className="label-tag mb-4">Transparent Pricing</p>
        <h1 className="display-section text-cream mb-4">Choose Your Path</h1>
        <p className="text-cream/40 max-w-lg mx-auto text-sm leading-relaxed">
          Consumer formulas. Professional Lab Packs. Executive education. One ecosystem built for the beauty industry.
        </p>
      </div>

      <div className="container-md mb-12 flex justify-center">
        <div className="inline-flex border border-gold/20 bg-obsidian">
          {([['consumer','Consumer',<Sparkles key="s" size={13}/>],['pro','Professional',<FlaskConical key="f" size={13}/>],['education','Education',<BookOpen key="b" size={13}/>]] as [TabKey, string, React.ReactNode][]).map(([k,label,icon]) => (
            <button key={k} onClick={() => setTab(k)}
              className={`flex items-center gap-2 px-6 py-3 text-sm transition-all duration-150 ${tab===k ? 'bg-gold text-ink font-medium' : 'text-cream/50 hover:text-cream'}`}>
              {icon}{label}
            </button>
          ))}
        </div>
      </div>

      <div className="container-lg">
        <div className="grid md:grid-cols-2 gap-6 max-w-3xl mx-auto">
          {PLANS[tab].map(p => (
            <PlanCard key={p.key} plan={p as any}
              color={tab==='consumer' ? 'gold' : tab==='pro' ? 'teal' : 'rose'} />
          ))}
        </div>
      </div>

      <div className="container-md mt-20 text-center">
        <div className="gold-line mb-8" />
        <p className="text-cream/30 text-xs leading-relaxed max-w-lg mx-auto">
          All payments secured by Stripe. Subscriptions cancel anytime from your dashboard.
          All formulas and Lab Packs are educational and cosmetic in nature only. Not medical advice.
        </p>
      </div>
    </main>
  )
}
