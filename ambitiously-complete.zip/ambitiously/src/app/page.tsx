// src/app/page.tsx
import Link from 'next/link'
import { ArrowRight, Sparkles, BookOpen, FlaskConical, ShieldCheck } from 'lucide-react'

export default function HomePage() {
  return (
    <main className="min-h-screen bg-ink">
      <Nav />
      <Hero />
      <ThreeRevenue />
      <HowItWorks />
      <Testimonial />
      <PricingTeaser />
      <Footer />
    </main>
  )
}

function Nav() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-gold/10 bg-ink/90 backdrop-blur-md">
      <div className="container-lg flex items-center justify-between h-16">
        <Link href="/" className="font-display text-xl text-cream tracking-tight">
          Ambitiously <span className="text-gold">Institute</span>
        </Link>
        <div className="hidden md:flex items-center gap-8">
          <Link href="/c-ai" className="text-sm text-cream/60 hover:text-cream transition-colors">C-Ai Engine</Link>
          <Link href="/academy" className="text-sm text-cream/60 hover:text-cream transition-colors">Academy</Link>
          <Link href="/pricing" className="text-sm text-cream/60 hover:text-cream transition-colors">Pricing</Link>
          <Link href="/auth/signin" className="btn-outline text-xs py-2 px-4">Sign In</Link>
          <Link href="/start" className="btn-gold text-xs py-2 px-4">Get Started</Link>
        </div>
      </div>
    </nav>
  )
}

function Hero() {
  return (
    <section className="relative min-h-screen flex items-center noise-overlay overflow-hidden pt-16">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-ink via-obsidian to-ink" />
      <div className="absolute top-1/3 right-0 w-1/2 h-1/2 bg-gold/3 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-1/3 h-1/3 bg-teal/5 rounded-full blur-3xl" />

      <div className="container-lg relative z-10 py-20">
        <div className="max-w-3xl">
          <p className="label-tag mb-6 animate-in" style={{ animationDelay: '0.1s' }}>
            Skin Intelligence Engine — Est. 2025
          </p>

          <h1 className="display-hero text-cream mb-6 animate-in" style={{ animationDelay: '0.2s' }}>
            Where Science Meets{' '}
            <em className="text-gold not-italic">Skin</em>
          </h1>

          <p className="text-cream/60 text-lg leading-relaxed max-w-xl mb-10 animate-in" style={{ animationDelay: '0.3s' }}>
            AI-powered personalised formulation. Executive beauty education for professionals.
            The platform Conrad built from 20 years inside the industry.
          </p>

          <div className="flex flex-wrap gap-4 animate-in" style={{ animationDelay: '0.4s' }}>
            <Link href="/start" className="btn-gold">
              Analyse My Skin <ArrowRight size={16} />
            </Link>
            <Link href="/academy" className="btn-outline">
              Explore Academy
            </Link>
          </div>

          <div className="mt-16 flex gap-12 animate-in" style={{ animationDelay: '0.5s' }}>
            {[
              { n: '79+', l: 'Verified Ingredients' },
              { n: '3',   l: 'Certification Pathways' },
              { n: '20+', l: 'Years of Expertise' },
            ].map(s => (
              <div key={s.n}>
                <p className="font-display text-3xl text-gold">{s.n}</p>
                <p className="text-xs text-cream/40 mt-1 uppercase tracking-widest">{s.l}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

function ThreeRevenue() {
  const streams = [
    {
      icon: <Sparkles size={24} className="text-gold" />,
      tag:  'For Consumers',
      title: 'C-Ai Skin Analysis',
      desc:  'Upload your skin photo. Receive a personalised formula report built around your exact skin type, conditions, and concerns — with ingredient education at every step.',
      cta:  'Start Analysis',
      href: '/start',
      price: 'From $47',
    },
    {
      icon: <FlaskConical size={24} className="text-teal" />,
      tag:  'For Professionals',
      title: 'Pro Lab Pack',
      desc:  'Estheticians, makeup artists, and medspa operators. Build compliant, COSMOS-aligned formulas for your clients with professional Lab Pack PDFs ready for your lab partner.',
      cta:  'Go Pro',
      href: '/pricing#pro',
      price: 'From $97/mo',
    },
    {
      icon: <BookOpen size={24} className="text-rose" />,
      tag:  'Education',
      title: 'EBOS Program',
      desc:  'The Executive Beauty Operating System. Six tiers of transformation — from skin architecture to consultation mastery. The curriculum Conrad built for professionals who want to dominate.',
      cta:  'View Curriculum',
      href: '/academy',
      price: 'From $497',
    },
  ]

  return (
    <section className="section-pad bg-obsidian">
      <div className="container-lg">
        <p className="label-tag mb-4">The Ecosystem</p>
        <h2 className="display-section text-cream mb-4">Three Ways to Grow</h2>
        <div className="gold-line mb-16 max-w-xs" />

        <div className="grid md:grid-cols-3 gap-6">
          {streams.map(s => (
            <div key={s.title} className="card-dark flex flex-col">
              <div className="mb-4">{s.icon}</div>
              <p className="label-tag mb-2">{s.tag}</p>
              <h3 className="font-display text-2xl text-cream mb-3">{s.title}</h3>
              <p className="text-cream/50 text-sm leading-relaxed flex-1 mb-6">{s.desc}</p>
              <div className="flex items-center justify-between">
                <span className="font-display text-gold text-xl">{s.price}</span>
                <Link href={s.href} className="btn-outline text-xs py-2 px-4">
                  {s.cta} <ArrowRight size={12} />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function HowItWorks() {
  const steps = [
    { n: '01', title: 'Consultation',   desc: 'Complete your skin intake — lifestyle, conditions, sensitivities, concerns. The system builds your clinical profile.' },
    { n: '02', title: 'Skin Analysis',  desc: 'Upload a photo. C-Ai performs a Woods Lamp-style visual assessment using AI vision trained in clinical esthetics.' },
    { n: '03', title: 'Ingredient Education', desc: 'Before any recommendation, understand why each ingredient is selected. Education drives the sale, not pressure.' },
    { n: '04', title: 'Your Formula',   desc: 'Receive a personalised formula with AM/PM routine, compliance checks, and a downloadable PDF report.' },
  ]

  return (
    <section className="section-pad bg-ink">
      <div className="container-lg">
        <p className="label-tag mb-4">The Method</p>
        <h2 className="display-section text-cream mb-4">
          Educate. Entertain. Accommodate.
        </h2>
        <p className="text-cream/40 max-w-lg mb-16 text-sm leading-relaxed">
          The Caryl Baker Visage methodology, reimagined for the AI era. Every consultation follows the same principle: create the need through education, close through trust.
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map(s => (
            <div key={s.n}>
              <p className="font-display text-5xl text-gold/20 mb-4">{s.n}</p>
              <h3 className="font-display text-xl text-cream mb-2">{s.title}</h3>
              <p className="text-cream/40 text-sm leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function Testimonial() {
  return (
    <section className="section-pad bg-charcoal">
      <div className="container-md text-center">
        <p className="label-tag mb-8">The Philosophy</p>
        <blockquote className="font-display text-[clamp(1.5rem,3vw,2.5rem)] text-cream font-light leading-relaxed mb-8">
          &ldquo;Everybody has a sensitivity to something. The question isn&rsquo;t whether &mdash; it&rsquo;s <em className="text-gold">what</em>. C-Ai is built to find it before it finds you.&rdquo;
        </blockquote>
        <p className="text-cream/40 text-sm tracking-widest uppercase">— Conrad, Founder · Ambitiously Institute</p>
      </div>
    </section>
  )
}

function PricingTeaser() {
  return (
    <section className="section-pad bg-obsidian">
      <div className="container-lg text-center">
        <ShieldCheck size={32} className="text-gold mx-auto mb-6" />
        <h2 className="display-section text-cream mb-4">Ready to Start?</h2>
        <p className="text-cream/50 mb-10 max-w-lg mx-auto text-sm leading-relaxed">
          One platform. Consumer formulas. Professional Lab Packs. Executive education. Everything you need to educate, sell, and grow.
        </p>
        <div className="flex flex-wrap gap-4 justify-center">
          <Link href="/start" className="btn-gold">Analyse My Skin <ArrowRight size={16} /></Link>
          <Link href="/pricing" className="btn-outline">View All Plans</Link>
        </div>
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer className="border-t border-gold/10 bg-ink py-12">
      <div className="container-lg">
        <div className="flex flex-col md:flex-row justify-between gap-8 mb-8">
          <div>
            <p className="font-display text-xl text-cream mb-2">Ambitiously Institute</p>
            <p className="text-cream/30 text-xs max-w-xs">AI-powered skin intelligence and executive beauty education. Ottawa, Canada · Worldwide.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-8 text-sm">
            {[
              { heading: 'Platform', links: [['C-Ai Engine','/c-ai'],['For Professionals','/pricing#pro'],['Academy','/academy']] },
              { heading: 'Company',  links: [['About','/about'],['Pricing','/pricing'],['Contact','mailto:hello@ambitiouslyinstitute.com']] },
              { heading: 'Legal',    links: [['Privacy Policy','/privacy'],['Terms','/terms'],['Disclaimer','/disclaimer']] },
            ].map(col => (
              <div key={col.heading}>
                <p className="label-tag mb-3">{col.heading}</p>
                {col.links.map(([label, href]) => (
                  <Link key={label} href={href} className="block text-cream/40 hover:text-cream text-xs mb-2 transition-colors">
                    {label}
                  </Link>
                ))}
              </div>
            ))}
          </div>
        </div>
        <div className="gold-line mb-6" />
        <div className="flex flex-col md:flex-row justify-between gap-2 text-xs text-cream/20">
          <p>© {new Date().getFullYear()} Ambitiously Institute. All rights reserved.</p>
          <p>Educational and cosmetic in nature only. Not medical advice.</p>
        </div>
      </div>
    </footer>
  )
}
