// src/app/layout.tsx
import type { Metadata } from 'next'
import { Cormorant_Garamond, DM_Sans, DM_Mono } from 'next/font/google'
import './globals.css'
import { Providers } from './providers'

const cormorant = Cormorant_Garamond({
  subsets:  ['latin'],
  weight:   ['300', '400', '500', '600', '700'],
  style:    ['normal', 'italic'],
  variable: '--font-cormorant',
  display:  'swap',
})

const dmSans = DM_Sans({
  subsets:  ['latin'],
  weight:   ['300', '400', '500', '600'],
  variable: '--font-dm-sans',
  display:  'swap',
})

const dmMono = DM_Mono({
  subsets:  ['latin'],
  weight:   ['400', '500'],
  variable: '--font-dm-mono',
  display:  'swap',
})

export const metadata: Metadata = {
  title:       'Ambitiously Institute | C-Ai Skin Intelligence',
  description: 'Executive beauty education and AI-powered personalized skincare formulation. Educate, entertain, accommodate.',
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL!),
  openGraph: {
    title:       'Ambitiously Institute',
    description: 'Where skin intelligence meets luxury education.',
    siteName:    'Ambitiously Institute',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${cormorant.variable} ${dmSans.variable} ${dmMono.variable}`}>
      <body className="font-body bg-ink text-cream antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
