// src/app/academy/page.tsx
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import Link from 'next/link'
import { Lock, PlayCircle, CheckCircle, BookOpen, ArrowRight } from 'lucide-react'

const CURRICULUM = [
  {
    tier: '01',
    title: 'Structural Skin Science',
    description: 'The epidermis as a regulatory system. Barrier function, inflammatory cascades, cellular signaling. Speak from mechanism, not memorization.',
    lessons: ['The Stratum Corneum — Architecture of Protection','Transepidermal Water Loss & Hydration Mechanics','Inflammatory Cascade: From Trigger to Response','The Acid Mantle: pH and Microbial Balance','Fitzpatrick Classification & Melanogenesis','Skin Type vs. Skin Condition — The Critical Difference'],
    duration: '3.5 hrs',
    free: true,
  },
  {
    tier: '02',
    title: 'Ingredient Intelligence',
    description: 'Molecular pathways, contraindication matrices, layering architecture. Translate chemistry into client confidence.',
    lessons: ['Humectants: The Water Network','Emollients, Occlusives & the Lipid Matrix','Active Delivery Systems: pH, Percentages, Penetration','The Incompatibility Matrix — What Not to Layer','Preservative Science: Safety vs. Fear','INCI Language: Reading a Formula Like a Pro'],
    duration: '4 hrs',
    free: false,
  },
  {
    tier: '03',
    title: 'Consultation Architecture',
    description: 'Replace scripts with structured inquiry. Design conversations that extract, build trust, and close through education.',
    lessons: ['The 7-Step Consultation System','Intake Design: What to Ask and Why','Reading Skin Without a Woods Lamp','Creating the Need Without Pressure','The 2-Week Check-In Protocol','Handling Objections with Science'],
    duration: '3 hrs',
    free: false,
  },
  {
    tier: '04',
    title: 'Treatment Structuring',
    description: 'Architect 6-12 month skin transformation plans. Sequence treatments, manage client expectations, build retention.',
    lessons: ['Building the Transformation Roadmap','Treatment Sequencing by Concern','Layering Modalities: When & Why','Managing Purging vs. Reaction','Seasonal Skin Adjustments','The Retention Formula'],
    duration: '3.5 hrs',
    free: false,
  },
  {
    tier: '05',
    title: 'Brand Architecture',
    description: 'Build, price, and position your own product line. Lab partnerships, compliance, white-labeling, retail strategy.',
    lessons: ['Formulation-to-Market: The Lab Partner Process','Compliance: COSMOS, Health Canada, FDA Basics','Pricing Your Line for Margin','White-Label vs. Custom Formulation','Retail vs. Professional-Only Strategy','Building Your Dispensary Model'],
    duration: '4 hrs',
    free: false,
  },
  {
    tier: '06',
    title: 'Business Mastery',
    description: 'Revenue systems, client lifetime value, referral architecture, pricing strategy, and the operator mindset.',
    lessons: ['Revenue Architecture: Multiple Income Streams','Client Lifetime Value & Retention Math','Referral Systems That Actually Work','Pricing for Premium Positioning','The Medspa Operator Mindset','Building Your C-Ai Practice'],
    duration: '4 hrs',
    free: false,
  },
]

export default async function AcademyPage() {
  const session = await getServerSession(authOptions)
  const hasAccess = session && ['PRO','ADMIN'].includes((session.user as any)?.role ?? '')

  return (
    <main className="min-h-screen bg-ink pt-24 pb-32">
      <div className="container-lg">

        {/* Header */}
        <div className="max-w-2xl mb-16">
          <p className="label-tag mb-4">EBOS — Executive Beauty Operating System</p>
          <h1 className="display-section text-cream mb-4">
            Six Tiers. One <span className="text-gold italic">Transformation.</span>
          </h1>
          <p className="text-cream/50 text-sm leading-relaxed mb-8">
            Built by Conrad — 20 years of beauty industry expertise distilled into a curriculum that teaches you to think like a formulator, communicate like a clinician, and operate like an entrepreneur.
          </p>
          {!hasAccess && (
            <div className="flex flex-wrap gap-4">
              <Link href="/pricing#ebos" className="btn-gold">Enrol Now — From $497 <ArrowRight size={14} /></Link>
              <Link href="/pricing" className="btn-outline">View All Plans</Link>
            </div>
          )}
        </div>

        {/* Curriculum */}
        <div className="space-y-4">
          {CURRICULUM.map((tier, i) => (
            <div key={tier.tier} className="bg-obsidian border border-gold/10 overflow-hidden">
              <div className="flex items-start gap-6 p-6">
                <span className="font-display text-5xl text-gold/20 leading-none shrink-0">{tier.tier}</span>
                <div className="flex-1">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h2 className="font-display text-2xl text-cream mb-2">{tier.title}</h2>
                      <p className="text-cream/50 text-sm leading-relaxed max-w-xl">{tier.description}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-xs text-cream/30 mb-2">{tier.duration}</p>
                      {tier.free ? (
                        <span className="text-xs bg-teal/20 text-teal-light px-2 py-1">Free Preview</span>
                      ) : (
                        <span className="text-xs bg-gold/10 text-gold px-2 py-1">Full Access</span>
                      )}
                    </div>
                  </div>

                  {/* Lessons */}
                  <div className="mt-4 grid md:grid-cols-2 gap-2">
                    {tier.lessons.map((lesson, j) => (
                      <div key={lesson} className="flex items-center gap-2">
                        {hasAccess || (tier.free && j === 0) ? (
                          <PlayCircle size={14} className="text-gold shrink-0" />
                        ) : (
                          <Lock size={14} className="text-cream/20 shrink-0" />
                        )}
                        <span className={`text-sm ${hasAccess || (tier.free && j === 0) ? 'text-cream/70 hover:text-cream cursor-pointer' : 'text-cream/30'}`}>
                          {lesson}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {!hasAccess && (
          <div className="mt-16 bg-charcoal border border-gold/20 p-10 text-center">
            <BookOpen size={32} className="text-gold mx-auto mb-4" />
            <h2 className="font-display text-3xl text-cream mb-3">Ready to transform your practice?</h2>
            <p className="text-cream/50 text-sm mb-8 max-w-lg mx-auto">
              One-time enrollment. Lifetime access. The most comprehensive professional beauty education built on 20 years of industry experience.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link href="/pricing#ebos" className="btn-gold">Enrol — $497 One-Time <ArrowRight size={14} /></Link>
              <Link href="/pricing#ebos" className="btn-outline">EBOS Elite + Coaching — $997</Link>
            </div>
          </div>
        )}
      </div>
    </main>
  )
}
