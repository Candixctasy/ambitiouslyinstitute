// src/lib/stripe.ts
import Stripe from 'stripe'

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-06-20',
})

export const PLANS = {
  CONSUMER_BASIC: {
    priceId:     process.env.STRIPE_PRICE_CONSUMER_BASIC!,
    name:        'Skin Report',
    description: 'One complete personalized formula report',
    amount:      4700,
    mode:        'payment' as const,
    features:    ['AI skin analysis', 'Custom formula', 'AM/PM routine', 'Ingredient education', 'PDF download'],
  },
  CONSUMER_PRO: {
    priceId:     process.env.STRIPE_PRICE_CONSUMER_PRO!,
    name:        'C-Ai Member',
    description: 'Unlimited reports + follow-up consultations',
    amount:      9700,
    mode:        'subscription' as const,
    features:    ['Everything in Basic', 'Unlimited analyses', '2-week check-in protocol', 'Reformulation access', 'Priority support'],
  },
  PRO_STARTER: {
    priceId:     process.env.STRIPE_PRICE_PRO_STARTER!,
    name:        'Pro Starter',
    description: 'For estheticians and makeup artists',
    amount:      9700,
    mode:        'subscription' as const,
    features:    ['Up to 10 active clients', 'Lab Pack PDFs', 'Compliance-checked formulas', 'COSMOS/ECOCERT paths', 'Health Canada rules engine'],
  },
  PRO_UNLIMITED: {
    priceId:     process.env.STRIPE_PRICE_PRO_UNLIMITED!,
    name:        'Pro Unlimited',
    description: 'For medspa operators and brand builders',
    amount:      19700,
    mode:        'subscription' as const,
    features:    ['Unlimited clients', 'White-label Lab Packs', 'All compliance pathways', 'Admin dashboard', 'Priority formulation queue'],
  },
  EBOS_COURSE: {
    priceId:     process.env.STRIPE_PRICE_EBOS_COURSE!,
    name:        'EBOS Program',
    description: 'Complete executive beauty education',
    amount:      49700,
    mode:        'payment' as const,
    features:    ['6 complete tiers', '40+ lessons', 'Certification of completion', 'Lifetime access', 'Community access'],
  },
  EBOS_ELITE: {
    priceId:     process.env.STRIPE_PRICE_EBOS_ELITE!,
    name:        'EBOS Elite',
    description: 'Program + 1:1 coaching with Conrad',
    amount:      99700,
    mode:        'payment' as const,
    features:    ['Everything in EBOS', '3 private coaching sessions', 'Brand strategy review', 'Formula consultation', 'Alumni network access'],
  },
} as const

export type PlanKey = keyof typeof PLANS

export async function createCheckoutSession({
  planKey,
  userId,
  userEmail,
  successUrl,
  cancelUrl,
}: {
  planKey:    PlanKey
  userId:     string
  userEmail:  string
  successUrl: string
  cancelUrl:  string
}) {
  const plan = PLANS[planKey]

  // Get or create Stripe customer
  const dbUser = await import('@/lib/prisma').then(m =>
    m.prisma.user.findUnique({ where: { id: userId } })
  )

  let customerId = dbUser?.stripeCustomerId
  if (!customerId) {
    const customer = await stripe.customers.create({ email: userEmail, metadata: { userId } })
    customerId = customer.id
    await import('@/lib/prisma').then(m =>
      m.prisma.user.update({ where: { id: userId }, data: { stripeCustomerId: customerId } })
    )
  }

  const session = await stripe.checkout.sessions.create({
    customer:   customerId,
    mode:       plan.mode,
    line_items: [{ price: plan.priceId, quantity: 1 }],
    success_url: successUrl,
    cancel_url:  cancelUrl,
    metadata: { userId, planKey },
    ...(plan.mode === 'subscription' && {
      subscription_data: { metadata: { userId, planKey } },
    }),
  })

  return session
}

export async function createCustomerPortalSession(customerId: string, returnUrl: string) {
  return stripe.billingPortal.sessions.create({ customer: customerId, return_url: returnUrl })
}
