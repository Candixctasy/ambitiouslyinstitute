// src/lib/pdf-generator.ts
import { PDFDocument, rgb, StandardFonts, PDFPage, PDFFont } from 'pdf-lib'
import type { FormulaResult } from './formulation-engine'

const GOLD   = rgb(0.722, 0.576, 0.247)
const INK    = rgb(0.055, 0.047, 0.039)
const CREAM  = rgb(0.961, 0.941, 0.910)
const GREY   = rgb(0.5, 0.5, 0.5)
const WHITE  = rgb(1, 1, 1)
const TEAL   = rgb(0.165, 0.482, 0.455)
const ALERT  = rgb(0.878, 0.361, 0.294)

interface DrawOptions {
  page: PDFPage
  x: number
  y: number
  size?: number
  color?: ReturnType<typeof rgb>
  font?: PDFFont
  maxWidth?: number
}

function drawText(text: string, opts: DrawOptions) {
  opts.page.drawText(text, {
    x: opts.x, y: opts.y,
    size: opts.size ?? 10,
    color: opts.color ?? INK,
    font: opts.font,
    maxWidth: opts.maxWidth,
  })
}

function drawLine(page: PDFPage, x1: number, y1: number, x2: number, y2: number, color = GOLD, thickness = 0.5) {
  page.drawLine({ start: { x: x1, y: y1 }, end: { x: x2, y: y2 }, thickness, color })
}

// ─── CONSUMER REPORT ─────────────────────────────────────────────
export async function generateConsumerReport(
  formula: FormulaResult,
  userName: string,
  date: Date = new Date()
): Promise<Uint8Array> {
  const doc  = await PDFDocument.create()
  const bold = await doc.embedFont(StandardFonts.HelveticaBold)
  const reg  = await doc.embedFont(StandardFonts.Helvetica)
  const W = 595, H = 842 // A4

  // ── PAGE 1: COVER ──────────────────────────────────────────────
  let page = doc.addPage([W, H])

  // Background
  page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: INK })

  // Gold accent bar
  page.drawRectangle({ x: 0, y: H - 8, width: W, height: 8, color: GOLD })

  // Brand
  drawText('AMBITIOUSLY INSTITUTE', { page, x: 50, y: H - 60, size: 9, color: GOLD, font: bold })
  drawText('+ C-AI SKIN INTELLIGENCE ENGINE', { page, x: 50, y: H - 75, size: 7, color: rgb(0.7, 0.6, 0.4), font: reg })

  // Report title
  drawText('PERSONALISED', { page, x: 50, y: H - 200, size: 36, color: CREAM, font: bold })
  drawText('FORMULA REPORT', { page, x: 50, y: H - 240, size: 36, color: GOLD, font: bold })

  drawLine(page, 50, H - 260, W - 50, H - 260, GOLD, 1)

  drawText(`Prepared for: ${userName}`, { page, x: 50, y: H - 290, size: 12, color: CREAM, font: reg })
  drawText(`Product: ${formula.productName}`, { page, x: 50, y: H - 310, size: 12, color: rgb(0.8, 0.7, 0.5), font: reg })
  drawText(`Date: ${date.toLocaleDateString('en-CA', { year: 'numeric', month: 'long', day: 'numeric' })}`, {
    page, x: 50, y: H - 330, size: 10, color: GREY, font: reg,
  })

  // Disclaimer box
  page.drawRectangle({ x: 50, y: 80, width: W - 100, height: 80, color: rgb(0.12, 0.10, 0.08), borderColor: GOLD, borderWidth: 0.5 })
  drawText('IMPORTANT NOTICE', { page, x: 62, y: 145, size: 8, color: GOLD, font: bold })
  drawText(formula.consumerNote, { page, x: 62, y: 130, size: 7, color: rgb(0.7, 0.7, 0.7), font: reg, maxWidth: W - 124 })

  // ── PAGE 2: FORMULA ────────────────────────────────────────────
  page = doc.addPage([W, H])
  page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: CREAM })
  page.drawRectangle({ x: 0, y: H - 8, width: W, height: 8, color: GOLD })

  let y = H - 50
  drawText('YOUR FORMULA', { page, x: 50, y, size: 18, color: INK, font: bold })
  y -= 8
  drawLine(page, 50, y, W - 50, y, GOLD, 0.5)
  y -= 20

  // Table header
  page.drawRectangle({ x: 50, y: y - 16, width: W - 100, height: 20, color: INK })
  drawText('INGREDIENT', { page, x: 56, y: y - 12, size: 8, color: GOLD, font: bold })
  drawText('INCI NAME', { page, x: 200, y: y - 12, size: 8, color: GOLD, font: bold })
  drawText('%', { page, x: 360, y: y - 12, size: 8, color: GOLD, font: bold })
  drawText('FUNCTION', { page, x: 400, y: y - 12, size: 8, color: GOLD, font: bold })
  y -= 22

  let row = 0
  for (const ing of formula.ingredients) {
    if (y < 80) { page = doc.addPage([W, H]); page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: CREAM }); y = H - 50 }

    if (row % 2 === 0) {
      page.drawRectangle({ x: 50, y: y - 14, width: W - 100, height: 18, color: rgb(0.94, 0.93, 0.91) })
    }

    const tierColor = ing.tier === 'ESSENTIAL' ? TEAL : ing.tier === 'BENEFICIAL' ? GOLD : GREY
    page.drawCircle({ x: 54, y: y - 5, size: 3, color: tierColor })
    drawText(ing.commonName, { page, x: 60, y: y - 10, size: 8, color: INK, font: reg, maxWidth: 135 })
    drawText(ing.inci, { page, x: 200, y: y - 10, size: 7, color: GREY, font: reg, maxWidth: 150 })
    drawText(`${ing.percentage}%`, { page, x: 360, y: y - 10, size: 8, color: INK, font: bold })
    drawText(ing.function.substring(0, 40), { page, x: 400, y: y - 10, size: 7, color: GREY, font: reg, maxWidth: 140 })

    y -= 20
    row++
  }

  // ── PAGE 3: ROUTINE + WARNINGS ────────────────────────────────
  page = doc.addPage([W, H])
  page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: CREAM })
  page.drawRectangle({ x: 0, y: H - 8, width: W, height: 8, color: GOLD })

  y = H - 50
  drawText('YOUR ROUTINE', { page, x: 50, y, size: 18, color: INK, font: bold })
  y -= 8; drawLine(page, 50, y, W - 50, y, GOLD, 0.5); y -= 25

  drawText('MORNING ROUTINE', { page, x: 50, y, size: 10, color: TEAL, font: bold }); y -= 15
  for (let i = 0; i < formula.amRoutine.length; i++) {
    drawText(`${i + 1}.  ${formula.amRoutine[i]}`, { page, x: 60, y, size: 9, color: INK, font: reg }); y -= 14
  }

  y -= 15
  drawText('EVENING ROUTINE', { page, x: 50, y, size: 10, color: GOLD, font: bold }); y -= 15
  for (let i = 0; i < formula.pmRoutine.length; i++) {
    drawText(`${i + 1}.  ${formula.pmRoutine[i]}`, { page, x: 60, y, size: 9, color: INK, font: reg }); y -= 14
  }

  if (formula.warnings.length > 0) {
    y -= 20
    drawText('IMPORTANT NOTES', { page, x: 50, y, size: 10, color: ALERT, font: bold }); y -= 15
    for (const w of formula.warnings) {
      drawText(`•  ${w}`, { page, x: 60, y, size: 8, color: INK, font: reg, maxWidth: W - 120 }); y -= 18
    }
  }

  if (formula.certPaths.length > 0) {
    y -= 20
    drawText('CERTIFICATION PATHWAYS', { page, x: 50, y, size: 10, color: TEAL, font: bold }); y -= 15
    for (const c of formula.certPaths) {
      drawText(`✓  ${c}`, { page, x: 60, y, size: 9, color: TEAL, font: reg }); y -= 14
    }
  }

  // Footer all pages
  for (const p of doc.getPages()) {
    drawText('© Ambitiously Institute  |  c-ai.ambitiouslyinstitute.com  |  This report is educational and cosmetic in nature only.', {
      page: p, x: 50, y: 20, size: 6, color: GREY, font: reg
    })
  }

  return doc.save()
}

// ─── PRO LAB PACK ─────────────────────────────────────────────────
export async function generateLabPack(
  formula: FormulaResult,
  proName: string,
  clientName: string,
  date: Date = new Date()
): Promise<Uint8Array> {
  const doc  = await PDFDocument.create()
  const bold = await doc.embedFont(StandardFonts.HelveticaBold)
  const reg  = await doc.embedFont(StandardFonts.Helvetica)
  const W = 595, H = 842

  // Cover
  let page = doc.addPage([W, H])
  page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: INK })
  page.drawRectangle({ x: 0, y: H - 8, width: W, height: 8, color: GOLD })

  // DRAFT watermark
  page.drawText('DRAFT', {
    x: 150, y: 350, size: 120, color: rgb(0.2, 0.17, 0.14), font: bold,
    rotate: { type: 'degrees', angle: 45 },
  })

  drawText('AMBITIOUSLY INSTITUTE', { page, x: 50, y: H - 60, size: 9, color: GOLD, font: bold })
  drawText('C-AI PROFESSIONAL LAB PACK', { page, x: 50, y: H - 75, size: 7, color: rgb(0.7, 0.6, 0.4), font: reg })

  drawText('LABORATORY', { page, x: 50, y: H - 200, size: 36, color: CREAM, font: bold })
  drawText('FORMULATION PACK', { page, x: 50, y: H - 240, size: 28, color: GOLD, font: bold })
  drawLine(page, 50, H - 260, W - 50, H - 260, GOLD, 1)

  drawText(`Professional: ${proName}`, { page, x: 50, y: H - 290, size: 11, color: CREAM, font: reg })
  drawText(`Client Reference: ${clientName}`, { page, x: 50, y: H - 308, size: 11, color: CREAM, font: reg })
  drawText(`Formula: ${formula.productName}`, { page, x: 50, y: H - 326, size: 11, color: rgb(0.8, 0.7, 0.5), font: reg })
  drawText(`Date: ${date.toLocaleDateString('en-CA', { year: 'numeric', month: 'long', day: 'numeric' })}`, {
    page, x: 50, y: H - 344, size: 10, color: GREY, font: reg,
  })

  // Lab disclaimer box
  page.drawRectangle({ x: 50, y: 60, width: W - 100, height: 110, color: rgb(0.12, 0.10, 0.08), borderColor: ALERT, borderWidth: 1 })
  drawText('LAB VALIDATION REQUIRED', { page, x: 62, y: 153, size: 8, color: ALERT, font: bold })
  const disclaimer = 'This document is a DRAFT formulation reference only. It must be reviewed and validated by a licensed cosmetic chemist before manufacture. Required pre-market steps: (1) Stability testing — 3 & 6 month accelerated; (2) Preservative Efficacy Testing (PET); (3) Safety Assessment by qualified assessor; (4) Health Canada cosmetic notification; (5) Label compliance review. This document does not constitute regulatory approval.'
  drawText(disclaimer, { page, x: 62, y: 138, size: 6.5, color: rgb(0.75, 0.65, 0.65), font: reg, maxWidth: W - 124 })

  // Phase breakdown page
  page = doc.addPage([W, H])
  page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: CREAM })
  page.drawRectangle({ x: 0, y: H - 8, width: W, height: 8, color: GOLD })

  let y = H - 50
  drawText('PHASE BREAKDOWN', { page, x: 50, y, size: 18, color: INK, font: bold })
  y -= 8; drawLine(page, 50, y, W - 50, y, GOLD, 0.5); y -= 20

  for (const instr of formula.instructions) {
    drawText(instr.phase, { page, x: 50, y, size: 11, color: TEAL, font: bold }); y -= 15
    for (const step of instr.steps) {
      drawText(`  ${step}`, { page, x: 60, y, size: 8.5, color: INK, font: reg, maxWidth: W - 120 }); y -= 14
    }
    y -= 8
    if (y < 80) { page = doc.addPage([W, H]); page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: CREAM }); y = H - 50 }
  }

  // Full ingredient spec table
  page = doc.addPage([W, H])
  page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: CREAM })
  page.drawRectangle({ x: 0, y: H - 8, width: W, height: 8, color: GOLD })

  y = H - 50
  drawText('INGREDIENT SPECIFICATION', { page, x: 50, y, size: 18, color: INK, font: bold })
  y -= 8; drawLine(page, 50, y, W - 50, y, GOLD, 0.5); y -= 20

  page.drawRectangle({ x: 50, y: y - 16, width: W - 100, height: 20, color: INK })
  drawText('INCI / COMMON NAME', { page, x: 56, y: y - 12, size: 8, color: GOLD, font: bold })
  drawText('PHASE', { page, x: 260, y: y - 12, size: 8, color: GOLD, font: bold })
  drawText('%', { page, x: 300, y: y - 12, size: 8, color: GOLD, font: bold })
  drawText('CAT.', { page, x: 340, y: y - 12, size: 8, color: GOLD, font: bold })
  drawText('FUNCTION', { page, x: 390, y: y - 12, size: 8, color: GOLD, font: bold })
  y -= 24

  let row = 0
  for (const ing of formula.ingredients) {
    if (y < 80) {
      page = doc.addPage([W, H])
      page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: CREAM })
      y = H - 50
    }
    if (row % 2 === 0) page.drawRectangle({ x: 50, y: y - 14, width: W - 100, height: 18, color: rgb(0.94, 0.93, 0.91) })

    drawText(`${ing.inci} / ${ing.commonName}`, { page, x: 56, y: y - 10, size: 7.5, color: INK, font: reg, maxWidth: 198 })
    drawText(ing.phase, { page, x: 260, y: y - 10, size: 8, color: TEAL, font: bold })
    drawText(`${ing.percentage}%`, { page, x: 300, y: y - 10, size: 8, color: INK, font: bold })
    drawText(ing.category.substring(0, 10), { page, x: 340, y: y - 10, size: 7, color: GREY, font: reg })
    drawText(ing.function.substring(0, 45), { page, x: 390, y: y - 10, size: 7, color: GREY, font: reg, maxWidth: 150 })

    y -= 20; row++
  }

  // Footer
  for (const p of doc.getPages()) {
    drawText('DRAFT — AMBITIOUSLY INSTITUTE | Lab validation required before manufacture | ambitiouslyinstitute.com', {
      page: p, x: 50, y: 20, size: 6, color: GREY, font: reg
    })
  }

  return doc.save()
}
