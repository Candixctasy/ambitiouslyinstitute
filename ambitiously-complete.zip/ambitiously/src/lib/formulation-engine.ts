// src/lib/formulation-engine.ts
import { SkinType, ProductType } from '@prisma/client'

// ─── TYPES ───────────────────────────────────────────────────────
export interface IntakeData {
  skinType:       SkinType
  conditions:     string[]
  concerns:       string[]
  sensitivities:  string[]
  pregnant:       boolean
  cosmos:         boolean
  routineLength:  'minimal' | 'moderate' | 'comprehensive'
  budget:         'accessible' | 'mid' | 'luxury'
  productType:    ProductType
  mode:           'CONSUMER' | 'PRO'
}

export interface FormulaIngredient {
  inci:        string
  commonName:  string
  category:    string
  percentage:  number
  phase:       'A' | 'B' | 'C' | 'D'
  function:    string
  tier:        'ESSENTIAL' | 'BENEFICIAL' | 'OPTIONAL'
  rationale:   string
}

export interface FormulaResult {
  productType:     ProductType
  productName:     string
  totalPercentage: number
  ingredients:     FormulaIngredient[]
  instructions:    { phase: string; steps: string[] }[]
  amRoutine:       string[]
  pmRoutine:       string[]
  warnings:        string[]
  consumerNote:    string
  labNote?:        string    // PRO mode only
  certPaths:       string[]
}

// ─── INGREDIENT REFERENCE LIBRARY ────────────────────────────────
const INGREDIENTS: Record<string, Omit<FormulaIngredient, 'percentage' | 'tier' | 'rationale'> & {
  pctRange: [number, number]
  skinTypes: SkinType[]
  concerns: string[]
  conditions: string[]
  incompatible: string[]
  pregnancySafe: boolean
  cosmos: boolean
  hotlistCap?: number
}> = {
  'AQUA': {
    inci: 'Aqua', commonName: 'Purified Water', category: 'SOLVENT',
    phase: 'A', function: 'Solvent base, hydration vehicle',
    pctRange: [40, 85], skinTypes: Object.values(SkinType) as SkinType[],
    concerns: [], conditions: [], incompatible: [], pregnancySafe: true, cosmos: true,
  },
  'GLYCERIN': {
    inci: 'Glycerin', commonName: 'Vegetable Glycerin', category: 'HUMECTANT',
    phase: 'A', function: 'Humectant, draws moisture into skin',
    pctRange: [2, 10], skinTypes: Object.values(SkinType) as SkinType[],
    concerns: ['dehydration', 'dullness', 'texture'], conditions: [],
    incompatible: [], pregnancySafe: true, cosmos: true,
  },
  'NIACINAMIDE': {
    inci: 'Niacinamide', commonName: 'Vitamin B3', category: 'ACTIVE',
    phase: 'A', function: 'Brightening, barrier support, pore refinement',
    pctRange: [2, 10], skinTypes: [SkinType.OILY, SkinType.COMBINATION, SkinType.NORMAL, SkinType.SENSITIVE],
    concerns: ['hyperpigmentation', 'enlarged_pores', 'dullness', 'texture'],
    conditions: ['acne', 'rosacea'],
    incompatible: ['VITAMIN_C_L_AA'], pregnancySafe: true, cosmos: false,
  },
  'HYALURONIC_ACID': {
    inci: 'Sodium Hyaluronate', commonName: 'Hyaluronic Acid', category: 'HUMECTANT',
    phase: 'A', function: 'Multi-weight hydration, plumping',
    pctRange: [0.5, 2], skinTypes: Object.values(SkinType) as SkinType[],
    concerns: ['dehydration', 'fine_lines', 'plumping'], conditions: [],
    incompatible: [], pregnancySafe: true, cosmos: true,
  },
  'CERAMIDE_NP': {
    inci: 'Ceramide NP', commonName: 'Ceramide', category: 'EMOLLIENT',
    phase: 'B', function: 'Barrier repair, lipid replenishment',
    pctRange: [0.5, 3], skinTypes: [SkinType.DRY, SkinType.SENSITIVE, SkinType.MATURE],
    concerns: ['barrier_damage', 'sensitivity', 'dryness'], conditions: ['eczema'],
    incompatible: [], pregnancySafe: true, cosmos: false,
  },
  'RETINOL': {
    inci: 'Retinol', commonName: 'Vitamin A', category: 'ACTIVE',
    phase: 'B', function: 'Cell turnover, collagen stimulation, anti-aging',
    pctRange: [0.025, 0.3], skinTypes: [SkinType.NORMAL, SkinType.OILY, SkinType.COMBINATION, SkinType.MATURE],
    concerns: ['fine_lines', 'wrinkles', 'texture', 'acne_scarring'],
    conditions: ['acne'],
    incompatible: ['GLYCOLIC_ACID', 'LACTIC_ACID', 'SALICYLIC_ACID', 'VITAMIN_C_L_AA'],
    pregnancySafe: false, cosmos: false, hotlistCap: 0.3,
  },
  'VITAMIN_C_L_AA': {
    inci: 'Ascorbic Acid', commonName: 'Vitamin C (L-Ascorbic Acid)', category: 'ANTIOXIDANT',
    phase: 'B', function: 'Brightening, antioxidant, collagen synthesis',
    pctRange: [10, 20], skinTypes: [SkinType.NORMAL, SkinType.OILY, SkinType.COMBINATION, SkinType.MATURE],
    concerns: ['hyperpigmentation', 'dullness', 'antioxidant', 'fine_lines'],
    conditions: [],
    incompatible: ['NIACINAMIDE', 'RETINOL', 'AHA_BHA_COMBO'],
    pregnancySafe: true, cosmos: false,
  },
  'GLYCOLIC_ACID': {
    inci: 'Glycolic Acid', commonName: 'Glycolic Acid (AHA)', category: 'EXFOLIANT',
    phase: 'A', function: 'Chemical exfoliation, brightening, texture',
    pctRange: [2, 10], skinTypes: [SkinType.NORMAL, SkinType.OILY, SkinType.COMBINATION, SkinType.MATURE],
    concerns: ['texture', 'dullness', 'hyperpigmentation', 'fine_lines'],
    conditions: ['acne'],
    incompatible: ['RETINOL', 'VITAMIN_C_L_AA', 'SALICYLIC_ACID'],
    pregnancySafe: true, cosmos: false,
  },
  'SALICYLIC_ACID': {
    inci: 'Salicylic Acid', commonName: 'BHA / Salicylic Acid', category: 'EXFOLIANT',
    phase: 'A', function: 'Oil-soluble exfoliant, unclogs pores, anti-inflammatory',
    pctRange: [0.5, 2], skinTypes: [SkinType.OILY, SkinType.COMBINATION],
    concerns: ['enlarged_pores', 'texture', 'congestion'],
    conditions: ['acne'],
    incompatible: ['RETINOL', 'GLYCOLIC_ACID'],
    pregnancySafe: false, cosmos: false, hotlistCap: 2.0,
  },
  'SQUALANE': {
    inci: 'Squalane', commonName: 'Plant-Derived Squalane', category: 'EMOLLIENT',
    phase: 'B', function: 'Lightweight emollient, barrier support, non-comedogenic',
    pctRange: [1, 10], skinTypes: Object.values(SkinType) as SkinType[],
    concerns: ['dryness', 'barrier_damage'], conditions: [],
    incompatible: [], pregnancySafe: true, cosmos: true,
  },
  'SHEA_BUTTER': {
    inci: 'Butyrospermum Parkii Butter', commonName: 'Shea Butter', category: 'EMOLLIENT',
    phase: 'B', function: 'Rich emollient, occlusive, anti-inflammatory fatty acids',
    pctRange: [2, 15], skinTypes: [SkinType.DRY, SkinType.MATURE, SkinType.SENSITIVE],
    concerns: ['dryness', 'barrier_damage'], conditions: [],
    incompatible: [], pregnancySafe: true, cosmos: true,
  },
  'PEPTIDE_MATRIXYL': {
    inci: 'Palmitoyl Tripeptide-1', commonName: 'Matrixyl (Peptide Complex)', category: 'PEPTIDE',
    phase: 'A', function: 'Collagen stimulation, wrinkle reduction, firming',
    pctRange: [0.1, 1], skinTypes: [SkinType.MATURE, SkinType.NORMAL, SkinType.DRY],
    concerns: ['fine_lines', 'wrinkles', 'firmness'],
    conditions: [],
    incompatible: [], pregnancySafe: true, cosmos: false,
  },
  'CENTELLA': {
    inci: 'Centella Asiatica Extract', commonName: 'Cica / Centella', category: 'ACTIVE',
    phase: 'A', function: 'Wound healing, calming, barrier strengthening',
    pctRange: [0.5, 5], skinTypes: [SkinType.SENSITIVE, SkinType.DRY, SkinType.NORMAL],
    concerns: ['sensitivity', 'redness', 'barrier_damage'], conditions: ['rosacea', 'eczema'],
    incompatible: [], pregnancySafe: true, cosmos: true,
  },
  'PHENOXYETHANOL': {
    inci: 'Phenoxyethanol', commonName: 'Phenoxyethanol', category: 'PRESERVATIVE',
    phase: 'C', function: 'Broad-spectrum preservative',
    pctRange: [0.5, 1], skinTypes: Object.values(SkinType) as SkinType[],
    concerns: [], conditions: [],
    incompatible: [], pregnancySafe: true, cosmos: false, hotlistCap: 1.0,
  },
  'ETHYLHEXYLGLYCERIN': {
    inci: 'Ethylhexylglycerin', commonName: 'Ethylhexylglycerin', category: 'PRESERVATIVE',
    phase: 'C', function: 'Preservative booster, skin conditioning',
    pctRange: [0.1, 0.5], skinTypes: Object.values(SkinType) as SkinType[],
    concerns: [], conditions: [],
    incompatible: [], pregnancySafe: true, cosmos: false,
  },
  'TOCOPHEROL': {
    inci: 'Tocopherol', commonName: 'Vitamin E', category: 'ANTIOXIDANT',
    phase: 'B', function: 'Antioxidant, skin conditioning, stabilizer',
    pctRange: [0.1, 1], skinTypes: Object.values(SkinType) as SkinType[],
    concerns: ['antioxidant', 'aging'], conditions: [],
    incompatible: [], pregnancySafe: true, cosmos: true,
  },
  'ALLANTOIN': {
    inci: 'Allantoin', commonName: 'Allantoin', category: 'ACTIVE',
    phase: 'A', function: 'Soothing, cell proliferation, keratolytic at higher %',
    pctRange: [0.1, 0.5], skinTypes: [SkinType.SENSITIVE, SkinType.DRY, SkinType.NORMAL],
    concerns: ['sensitivity', 'redness', 'texture'], conditions: ['rosacea'],
    incompatible: [], pregnancySafe: true, cosmos: true,
  },
  'PANTHENOL': {
    inci: 'Panthenol', commonName: 'Pro-Vitamin B5', category: 'HUMECTANT',
    phase: 'A', function: 'Humectant, wound healing, anti-inflammatory',
    pctRange: [0.5, 5], skinTypes: Object.values(SkinType) as SkinType[],
    concerns: ['barrier_damage', 'sensitivity', 'dehydration'], conditions: [],
    incompatible: [], pregnancySafe: true, cosmos: true,
  },
  'XANTHAN_GUM': {
    inci: 'Xanthan Gum', commonName: 'Xanthan Gum', category: 'THICKENER',
    phase: 'A', function: 'Viscosity builder, stabilizer',
    pctRange: [0.1, 0.8], skinTypes: Object.values(SkinType) as SkinType[],
    concerns: [], conditions: [],
    incompatible: [], pregnancySafe: true, cosmos: true,
  },
  'EMULSIFIER_OLIVEM': {
    inci: 'Cetearyl Olivate (and) Sorbitan Olivate', commonName: 'Olivem 1000', category: 'EMULSIFIER',
    phase: 'B', function: 'Natural O/W emulsifier, skin mimic lipid structure',
    pctRange: [3, 8], skinTypes: Object.values(SkinType) as SkinType[],
    concerns: [], conditions: [],
    incompatible: [], pregnancySafe: true, cosmos: true,
  },
  'ZINC_OXIDE': {
    inci: 'Zinc Oxide', commonName: 'Zinc Oxide (Mineral SPF)', category: 'ACTIVE',
    phase: 'B', function: 'Broad-spectrum UVA/UVB filter — NHP pathway required',
    pctRange: [5, 25], skinTypes: Object.values(SkinType) as SkinType[],
    concerns: [], conditions: [],
    incompatible: [], pregnancySafe: true, cosmos: true,
  },
}

// ─── INCOMPATIBILITY CHECK ───────────────────────────────────────
function hasConflict(a: string, b: string): boolean {
  const ia = INGREDIENTS[a]
  const ib = INGREDIENTS[b]
  if (!ia || !ib) return false
  return ia.incompatible.includes(b) || ib.incompatible.includes(a)
}

// ─── MAIN ENGINE ─────────────────────────────────────────────────
export function buildFormula(intake: IntakeData): FormulaResult {
  const warnings: string[] = []

  // SAFETY GATES
  if (intake.productType === 'SPF' && intake.mode === 'CONSUMER') {
    warnings.push('SPF formulations require NHP (Natural Health Product) regulatory approval in Canada. This product type is blocked in consumer mode. Please consult a licensed lab.')
    return {
      productType: intake.productType,
      productName: 'SPF — Blocked',
      totalPercentage: 0, ingredients: [],
      instructions: [], amRoutine: [], pmRoutine: [],
      warnings, consumerNote: warnings[0], certPaths: [],
    }
  }

  // Score ingredients by relevance
  const scored: { key: string; score: number }[] = []

  for (const [key, ing] of Object.entries(INGREDIENTS)) {
    if (key === 'ZINC_OXIDE' && intake.productType !== 'SPF') continue

    let score = 0

    // Pregnancy filter
    if (intake.pregnant && !ing.pregnancySafe) continue

    // COSMOS filter
    if (intake.cosmos && !ing.cosmos) {
      // Allow non-cosmos but flag it — don't exclude, reduce score
      score -= 5
    }

    // Skin type match
    if (ing.skinTypes.includes(intake.skinType)) score += 3

    // Concern match
    for (const c of intake.concerns) {
      if (ing.concerns.includes(c)) score += 4
    }

    // Condition match
    for (const c of intake.conditions) {
      if (ing.conditions.includes(c)) score += 4
    }

    // Sensitivity penalty
    for (const s of intake.sensitivities) {
      if (ing.inci.toLowerCase().includes(s.toLowerCase())) score -= 10
    }

    scored.push({ key, score })
  }

  scored.sort((a, b) => b.score - a.score)

  // Build ingredient list, removing conflicts
  const selected: string[] = []

  // Always include base ingredients
  const bases = ['AQUA', 'GLYCERIN', 'XANTHAN_GUM', 'PHENOXYETHANOL', 'ETHYLHEXYLGLYCERIN']
  for (const b of bases) {
    if (!selected.includes(b)) selected.push(b)
  }

  // Add emulsifier for creams/moisturizers
  if (['MOISTURIZER', 'EYE_CREAM', 'MASK'].includes(intake.productType)) {
    selected.push('EMULSIFIER_OLIVEM')
  }

  // Add high-scoring actives
  const maxActives = intake.routineLength === 'minimal' ? 2 : intake.routineLength === 'moderate' ? 3 : 5
  let activeCount = 0

  for (const { key } of scored) {
    if (selected.includes(key)) continue
    if (bases.includes(key)) continue
    if (activeCount >= maxActives) break

    const hasC = selected.some(s => hasConflict(s, key))
    if (hasC) {
      warnings.push(`${INGREDIENTS[key].commonName} omitted due to incompatibility with selected actives.`)
      continue
    }

    selected.push(key)
    activeCount++
  }

  // Assign percentages
  const result: FormulaIngredient[] = []
  let totalPct = 0

  for (const key of selected) {
    const ing = INGREDIENTS[key]
    if (!ing) continue

    let pct: number

    if (key === 'AQUA') {
      pct = 0 // will fill remainder
    } else {
      const [min, max] = ing.pctRange
      // Use typical mid-point
      pct = +(((min + max) / 2)).toFixed(2)
    }

    // Hotlist cap enforcement (Health Canada)
    if (ing.hotlistCap && pct > ing.hotlistCap) {
      pct = ing.hotlistCap
      warnings.push(`${ing.commonName} capped at ${ing.hotlistCap}% per Health Canada Hotlist.`)
    }

    // Score-based tier
    const sc = scored.find(s => s.key === key)?.score ?? 0
    const tier: FormulaIngredient['tier'] =
      bases.includes(key) ? 'ESSENTIAL' :
      sc >= 6 ? 'ESSENTIAL' :
      sc >= 2 ? 'BENEFICIAL' : 'OPTIONAL'

    result.push({
      inci:       ing.inci,
      commonName: ing.commonName,
      category:   ing.category,
      percentage: key === 'AQUA' ? 0 : pct,
      phase:      ing.phase,
      function:   ing.function,
      tier,
      rationale:  generateRationale(key, intake),
    })

    if (key !== 'AQUA') totalPct += pct
  }

  // Fill water to 100
  const aqua = result.find(r => r.inci === 'Aqua')
  if (aqua) {
    aqua.percentage = +(100 - totalPct).toFixed(2)
    totalPct = 100
  }

  // Sort by phase then percentage desc
  result.sort((a, b) => {
    if (a.phase < b.phase) return -1
    if (a.phase > b.phase) return 1
    return b.percentage - a.percentage
  })

  // Cert paths
  const certPaths: string[] = []
  const allCosmos = result.every(r => {
    const k = Object.keys(INGREDIENTS).find(k => INGREDIENTS[k].inci === r.inci)
    return k ? INGREDIENTS[k].cosmos : false
  })
  if (allCosmos) certPaths.push('COSMOS / ECOCERT eligible')
  if (allCosmos) certPaths.push('USDA Organic pathway available')

  // Pregnancy warning
  if (intake.pregnant) {
    warnings.push('Formula has been filtered for pregnancy safety. Always consult your healthcare provider before starting any new skincare regimen during pregnancy.')
  }

  const productName = generateProductName(intake)
  const consumerNote = `This formula has been generated based on your skin assessment. All recommendations are educational and cosmetic in nature. This is not medical advice. Results will vary. Perform a patch test before full application.`
  const labNote = intake.mode === 'PRO'
    ? `DRAFT — For laboratory reference only. Requires stability testing, PET (Preservative Efficacy Testing), and full regulatory review before manufacture or sale. Percentage fill for Aqua is indicative — adjust based on final phase weights.`
    : undefined

  return {
    productType:     intake.productType,
    productName,
    totalPercentage: totalPct,
    ingredients:     result,
    instructions:    generateInstructions(result),
    amRoutine:       generateRoutine('AM', intake),
    pmRoutine:       generateRoutine('PM', intake),
    warnings,
    consumerNote,
    labNote,
    certPaths,
  }
}

function generateRationale(key: string, intake: IntakeData): string {
  const ing = INGREDIENTS[key]
  if (!ing) return ''
  const matchedConcerns = ing.concerns.filter(c => intake.concerns.includes(c))
  const matchedConditions = ing.conditions.filter(c => intake.conditions.includes(c))
  if (matchedConcerns.length > 0 || matchedConditions.length > 0) {
    return `Selected for ${[...matchedConcerns, ...matchedConditions].join(', ')} — ${ing.function}.`
  }
  return ing.function
}

function generateProductName(intake: IntakeData): string {
  const typeNames: Partial<Record<ProductType, string>> = {
    CLEANSER:      'Balancing Cleanse',
    TONER:         'Refining Essence',
    SERUM:         'Intelligence Serum',
    MOISTURIZER:   'Skin Barrier Crème',
    EYE_CREAM:     'Eye Recovery Complex',
    MASK:          'Renewal Masque',
    TREATMENT_OIL: 'Nourishing Face Oil',
    MIST:          'Hydration Mist',
  }
  return `C-Ai ${typeNames[intake.productType] ?? intake.productType} — ${intake.skinType.charAt(0) + intake.skinType.slice(1).toLowerCase()} Skin`
}

function generateInstructions(ingredients: FormulaIngredient[]): { phase: string; steps: string[] }[] {
  const phases = [...new Set(ingredients.map(i => i.phase))].sort()
  return phases.map(phase => ({
    phase: `Phase ${phase}`,
    steps: [
      phase === 'A' ? 'Combine all Phase A water-soluble ingredients. Heat to 70–75°C with gentle stirring.' :
      phase === 'B' ? 'Combine all Phase B oil-soluble ingredients. Heat separately to 70–75°C.' :
      phase === 'C' ? 'Cool formula to below 40°C. Add Phase C ingredients with gentle mixing. Check pH.' :
      'Add Phase D ingredients at room temperature. Final pH adjustment and QC.',
      ...ingredients
        .filter(i => i.phase === phase)
        .map(i => `Add ${i.inci} (${i.commonName}) at ${i.percentage}%`),
    ],
  }))
}

function generateRoutine(time: 'AM' | 'PM', intake: IntakeData): string[] {
  const base = ['Cleanser', 'Toner/Essence', 'Serum (this formula)', 'Moisturizer']
  if (time === 'AM') return [...base, 'SPF 30+ (apply last — consult NHP-approved product)']
  return [...base, 'Facial oil (optional — seal moisture)']
}
