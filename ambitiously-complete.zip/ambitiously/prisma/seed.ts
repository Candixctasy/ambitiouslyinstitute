// prisma/seed.ts
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding Ambitiously Institute database…')

  // ─── ADMIN USER ──────────────────────────────────────────────
  const adminPw = await bcrypt.hash(process.env.ADMIN_PASSWORD || 'admin-change-me', 12)
  const admin = await prisma.user.upsert({
    where:  { email: 'admin@ambitiouslyinstitute.com' },
    update: {},
    create: {
      email:          'admin@ambitiouslyinstitute.com',
      name:           'Conrad — Admin',
      role:           'ADMIN',
      hashedPassword: adminPw,
    },
  })
  console.log('✅ Admin user:', admin.email)

  // ─── EBOS COURSE ─────────────────────────────────────────────
  const ebos = await prisma.course.upsert({
    where:  { slug: 'ebos' },
    update: {},
    create: {
      slug:        'ebos',
      title:       'Executive Beauty Operating System (EBOS)',
      description: 'The complete professional transformation curriculum. Six tiers of skin science, ingredient intelligence, consultation architecture, and business mastery. Designed for estheticians, makeup artists, and medspa operators who want to dominate their market.',
      price:       49700,
      plan:        'EBOS_COURSE',
      published:   true,
      order:       1,
    },
  })

  const MODULES = [
    {
      title: 'Tier I — Structural Skin Science', order: 1,
      lessons: [
        { title: 'The Stratum Corneum: Architecture of Protection', slug: 'stratum-corneum', duration: 35,
          content: `# The Stratum Corneum: Architecture of Protection\n\nThe stratum corneum is not simply the "dead layer" of skin — it is the most metabolically sophisticated barrier in the body. Understanding its architecture is the foundation of every product recommendation you will ever make.\n\n## The Brick-and-Mortar Model\n\nCorneocytes (the "bricks") are anucleate, keratin-filled cells embedded in a lipid matrix (the "mortar") composed primarily of ceramides (50%), cholesterol (25%), and free fatty acids (15%). This architecture creates a selective barrier that:\n\n- Prevents transepidermal water loss (TEWL)\n- Blocks percutaneous absorption of pathogens\n- Regulates pH at approximately 4.5–5.5\n- Coordinates desquamation via serine proteases\n\n## Clinical Relevance for Formulation\n\nWhen you formulate a moisturiser, you are not simply adding water to the skin. You are choosing whether to:\n\n1. **Attract water** (humectants: hyaluronic acid, glycerin, urea)\n2. **Fill lipid gaps** (emollients: squalane, ceramides, fatty acids)\n3. **Prevent evaporation** (occlusives: shea butter, petrolatum, beeswax)\n\nThe most effective barrier repair formulations mimic the natural lipid ratio. A serum of 3:1:1 ceramide:cholesterol:fatty acid ratio has been shown in multiple studies to restore barrier function within 48 hours.\n\n## Key Takeaway\n\nEvery time a client says their skin "feels tight," they are telling you their stratum corneum is compromised. Your first job is always barrier — before any active ingredient conversation.` },
        { title: 'Transepidermal Water Loss & Hydration Mechanics', slug: 'tewl-hydration', duration: 30,
          content: `# TEWL & Hydration Mechanics\n\nTransepidermal Water Loss (TEWL) is the passive evaporation of water through the epidermis. It is the single most important objective measurement of barrier integrity.\n\n## Normal TEWL Values\n\n- Healthy skin: 5–10 g/m²/hr\n- Mildly compromised: 10–20 g/m²/hr\n- Eczematous skin: 20–75 g/m²/hr\n\n## The Hydration-Retention Hierarchy\n\n**Step 1 — Attract (Humectants):** Apply to damp skin to pull moisture from the environment and dermis into the epidermis.\n\n**Step 2 — Fill (Emollients):** Smooth and soften by filling intercellular spaces with lipid-compatible molecules.\n\n**Step 3 — Lock (Occlusives):** Form a physical film to slow evaporation. Most effective when applied over hydrated skin.\n\n## The Layering Rule\n\nThinnest to thickest. Lowest molecular weight to highest. This is not aesthetics — it is physics. A thick occlusive applied before a hyaluronic acid serum will prevent the HA from reaching the stratum corneum entirely.` },
        { title: 'Inflammatory Cascade: From Trigger to Response', slug: 'inflammatory-cascade', duration: 28,
          content: `# The Inflammatory Cascade\n\nInflammation is not the enemy — uncontrolled inflammation is. Every skin condition you will ever treat has inflammation as a component. Understanding the cascade lets you intervene at the right step.\n\n## The 4 Stages\n\n1. **Trigger:** UV, microbes, allergens, irritants, trauma\n2. **Recognition:** Toll-like receptors (TLRs) on keratinocytes detect DAMPs/PAMPs\n3. **Amplification:** Cytokine release (IL-1, TNF-α, IL-6) recruits immune cells\n4. **Resolution or Chronicity:** Healthy skin resolves in 48–72 hours; compromised barrier creates a loop\n\n## Ingredients That Interrupt the Cascade\n\n- **Niacinamide** — inhibits NF-κB pathway, reducing cytokine production\n- **Centella asiatica** — asiaticoside stimulates collagen while madecassic acid suppresses IL-1β\n- **Zinc** — inhibits 5-alpha reductase and has direct anti-inflammatory action\n- **Azelaic acid** — targets inflammatory acne at the follicular level\n\n## The Rosacea Example\n\nRosacea is not "sensitive skin." It is a chronic relapsing inflammatory condition involving: neurovascular dysregulation → barrier dysfunction → microbiome disruption → innate immune activation. Treating it with "calming" products misses the mechanism. Treating it with barrier repair + anti-inflammatories + microbiome support addresses the root.` },
        { title: 'The Acid Mantle: pH and Microbial Balance', slug: 'acid-mantle', duration: 25,
          content: `# The Acid Mantle\n\nThe skin surface pH of 4.5–5.5 is not arbitrary. It is the precise range at which:\n\n- Serine proteases (desquamation enzymes) function optimally\n- Antimicrobial peptides are most active\n- Commensal bacteria (Cutibacterium acnes, Staphylococcus epidermidis) maintain homeostasis\n- Ceramide synthesis enzymes operate efficiently\n\n## What Disrupts the Acid Mantle\n\n- Alkaline cleansers (bar soaps typically pH 9–10)\n- Over-exfoliation with AHAs at incorrect frequency\n- Antibiotic overuse disrupting the cutaneous microbiome\n- Hard water (calcium/magnesium salts raise pH)\n\n## Formulation pH Targets\n\n| Product Type | Optimal pH |\n|---|---|\n| AHA exfoliant | 3.0–4.0 |\n| Vitamin C (L-AA) | 2.5–3.5 |\n| Cleanser | 4.5–6.5 |\n| Moisturiser | 5.5–7.0 |\n| Toner/Essence | 5.0–7.0 |\n\nA pH mismatch is the most common cause of "my skin doesn't tolerate X" complaints. Nine times out of ten, it's a sequencing or pH incompatibility issue, not a true sensitivity.` },
        { title: 'Fitzpatrick Classification & Melanogenesis', slug: 'fitzpatrick', duration: 22,
          content: `# Fitzpatrick Classification & Melanogenesis\n\n## The Fitzpatrick Scale\n\nDeveloped by Thomas B. Fitzpatrick in 1975, the scale classifies skin into 6 phototypes based on response to UV exposure:\n\n| Type | Description | Sun Response |\n|---|---|---|\n| I | Very fair, freckles | Always burns, never tans |\n| II | Fair | Usually burns, tans minimally |\n| III | Medium | Burns moderately, tans gradually |\n| IV | Olive | Rarely burns, tans well |\n| V | Brown | Very rarely burns, tans deeply |\n| VI | Dark brown/black | Never burns, deeply pigmented |\n\n## Melanogenesis: The Pigmentation Pathway\n\nMelanin production pathway: UV trigger → α-MSH → MC1R activation → tyrosinase upregulation → DOPA → dopaquinone → eumelanin (brown/black) or pheomelanin (red/yellow)\n\n## Ingredient Intervention Points\n\n- **Tyrosinase inhibitors:** Kojic acid, alpha-arbutin, tranexamic acid, azelaic acid\n- **Antioxidants (upstream):** Vitamin C (direct tyrosinase inhibitor + antioxidant)\n- **Cell turnover (downstream):** Retinoids accelerate transit of melanin-laden keratinocytes\n- **UV protection (prevention):** Zinc oxide, titanium dioxide (physical filters)` },
        { title: 'Skin Type vs. Skin Condition — The Critical Difference', slug: 'type-vs-condition', duration: 20,
          content: `# Skin Type vs. Skin Condition\n\nThis distinction is foundational to the C-Ai consultation system and separates educated practitioners from the rest of the industry.\n\n## Skin Type (Genetic, Relatively Stable)\n- Normal, Dry, Oily, Combination, Sensitive, Mature\n- Determined by sebaceous gland activity, lipid composition, and genetic factors\n- Changes slowly over decades (hormones, aging, climate)\n\n## Skin Condition (Environmental, Transient, Treatable)\n- Dehydration, acne, hyperpigmentation, rosacea, eczema, barrier damage\n- Can occur on ANY skin type\n- Responds to targeted treatment\n\n## The Most Common Mistake\n\nA client with oily skin says "I don't need moisturiser." Wrong. They have oily skin TYPE — but they may have dehydrated skin CONDITION. Dehydrated oily skin (stripped of water, overproducing sebum to compensate) is one of the most common presentations and is almost universally mismanaged.\n\n## The C-Ai Framework\n\nThe intake always asks BOTH:\n1. What is your skin type? (stable baseline)\n2. What conditions are currently presenting? (active treatment targets)\n\nThis is why a "sensitive skin" client with acne gets a completely different formula than a "sensitive skin" client with redness and no congestion — despite the same type classification.` },
      ],
    },
    {
      title: 'Tier II — Ingredient Intelligence', order: 2,
      lessons: [
        { title: 'Humectants: The Water Network', slug: 'humectants', duration: 32,
          content: `# Humectants: The Water Network\n\nHumectants are hygroscopic substances that draw moisture from their environment into the skin. They are the first layer of any hydration protocol.\n\n## The Key Players\n\n**Sodium Hyaluronate (Hyaluronic Acid)**\n- 1 gram holds up to 6 litres of water\n- Multiple molecular weights serve different depths\n- Low MW (5–50 kDa): deeper penetration, mild plumping\n- High MW (1–2 MDa): surface film, immediate texture improvement\n\n**Glycerin**\n- Most studied humectant in cosmetics\n- Effective at 2–10%\n- At >10% can draw moisture FROM skin in low-humidity environments\n- Optimal use: 3–5% in serums, 5–8% in moisturisers\n\n**Urea**\n- Dual-action: humectant + gentle keratolytic\n- 5–10%: hydration, barrier repair, mild exfoliation\n- 10–20%: therapeutic for keratosis pilaris, calluses\n- 20%+: true keratolytic (prescription territory)\n\n**Panthenol (Pro-B5)**\n- Converts to pantothenic acid in skin\n- Humectant + wound healing + anti-inflammatory\n- One of the safest, most well-tolerated actives available` },
        { title: 'Emollients, Occlusives & the Lipid Matrix', slug: 'emollients-occlusives', duration: 35,
          content: `# Emollients, Occlusives & the Lipid Matrix\n\n## Emollients: Filling the Gaps\n\nEmollients work by filling the spaces between skin cells with lipid-compatible molecules, creating a smooth, soft surface and supporting barrier function.\n\n**Squalane** — Derived from sugarcane (vegan) or shark liver. Mimics sebum exactly. Non-comedogenic, stable, suitable for all skin types including acne-prone.\n\n**Rosehip Oil (Rosa Canina)** — Rich in linoleic acid (essential fatty acid). Particularly effective for acne-prone skin where linoleic acid is depleted. Contains beta-carotene (Vitamin A precursor).\n\n**Ceramide NP** — The most important barrier lipid. Ceramides make up approximately 50% of the stratum corneum's lipid matrix. Ceramide NP (N-stearoyl phytosphingosine) directly replenishes the depleted barrier in eczema, rosacea, and stripped skin.\n\n## Occlusives: The Lock\n\n**Shea Butter (Butyrospermum Parkii)** — Rich in stearic and oleic acids. Contains triterpene compounds with inherent anti-inflammatory activity. Comedogenicity rating 0–2 (low).\n\n**Beeswax** — Film-forming occlusive. Creates a breathable, flexible barrier. Useful in balms and heavy creams.\n\n**Petrolatum** — The gold-standard occlusive. TEWL reduction of up to 99%. Despite its reputation, refined white petrolatum is non-comedogenic.` },
        { title: 'Active Delivery: pH, Percentages, Penetration', slug: 'active-delivery', duration: 38,
          content: `# Active Delivery: pH, Percentages, Penetration\n\nKnowing which actives to use is half the equation. Knowing how to deliver them to where they work is the other half.\n\n## The Three Variables\n\n### 1. pH\nMany actives are pH-dependent in both efficacy and stability:\n\n| Active | Effective pH | Notes |\n|---|---|---|\n| Vitamin C (L-AA) | 2.5–3.5 | Unstable above 3.5 |\n| Glycolic Acid | 3.0–4.0 | Below 3.5 = 70%+ free acid |\n| Salicylic Acid | 3.0–4.0 | Lipophilic, self-preserving |\n| Retinol | 4.5–6.5 | pH-sensitive to oxidation |\n| Niacinamide | 5.0–7.0 | Wide range, very stable |\n\n### 2. Concentration\n\nThe dose makes the medicine. Most actives have an effective range and a maximum safe range:\n\n- **Vitamin C:** Effective 10–20%. Diminishing returns above 20%.\n- **Retinol:** Start 0.025–0.05%. Work up to 0.3% over 3–6 months.\n- **Niacinamide:** 2–5% for brightening. 5–10% for sebum control.\n- **Glycolic Acid:** 5–10% for consumer use (Health Canada max 10%). 15–30% for professional treatments.\n\n### 3. Vehicle\n\nHow an active is delivered affects its penetration:\n- **Aqueous solution:** Good for water-soluble actives (HA, glycerin, niacinamide)\n- **Anhydrous formula:** Required for oil-soluble actives at high concentration\n- **Liposomal/encapsulated:** Controlled release, reduced irritation (retinol, Vitamin C)` },
        { title: 'The Incompatibility Matrix', slug: 'incompatibility-matrix', duration: 30,
          content: `# The Incompatibility Matrix\n\nThe most important skill in advanced formulation is not knowing what to add — it is knowing what NOT to combine.\n\n## Hard Incompatibilities (Never Combine in Same Application)\n\n| Combination | Reason |\n|---|---|\n| Vitamin C (L-AA) + Niacinamide | Forms niacin + nicotinic acid complex, causes transient flushing |\n| Retinol + AHAs/BHAs | Both induce cell turnover; combined = over-exfoliation, barrier disruption |\n| Retinol + Vitamin C | Competing pH requirements; C needs <3.5, retinol denatures there |\n| Benzoyl Peroxide + Retinol | BP oxidises retinol, rendering it inactive |\n| Vitamin C + Zinc | Zinc chelates ascorbic acid, reducing efficacy |\n\n## AM/PM Sequencing Strategy\n\nMany "incompatible" combinations can be used in the same routine by time-separation:\n\n- **AM:** Vitamin C serum → niacinamide moisturiser ✓ (different products, sequential)\n- **PM:** Retinol (PM only) — never pair with AHA in same session\n- **Alternate nights:** Retinol nights vs. AHA/BHA nights\n\n## The C-Ai Approach\n\nThe formulation engine checks every ingredient pair against the incompatibility matrix before building a formula. No conflicting actives will appear in the same product.` },
        { title: 'Preservative Science: Safety vs. Fear', slug: 'preservatives', duration: 25,
          content: `# Preservative Science: Safety vs. Fear\n\nThe most dangerous cosmetic product is an unpreserved one. Understanding preservative science lets you have evidence-based conversations when clients ask about "paraben-free" products.\n\n## The Function of Preservatives\n\nAny product containing water (aqueous phase) will support microbial growth within 24–72 hours without preservation. Contamination risks include:\n- Pseudomonas aeruginosa (opportunistic pathogen)\n- Staphylococcus aureus (skin infections)\n- Candida albicans (fungal contamination)\n- Aspergillus niger (mould)\n\n## Common Preservatives: Evidence vs. Perception\n\n**Parabens (methylparaben, propylparaben)**\n- Effective, stable, low sensitisation rate\n- The "estrogenic activity" concern: parabens bind estrogen receptors at 10,000–100,000× lower affinity than endogenous estrogen\n- WHO and EU Safety Committee conclude parabens are safe at approved concentrations\n- Maximum 0.4% single paraben, 0.8% mixture (EU/Health Canada)\n\n**Phenoxyethanol**\n- COSMOS-restricted (not approved as preservative in COSMOS products)\n- Health Canada Hotlist: max 1.0%\n- Well-tolerated in most formulas\n\n**Sodium Benzoate + Potassium Sorbate (Natural Pair)**\n- pH-dependent efficacy (effective below pH 5.5)\n- COSMOS/ECOCERT approved\n- Best for leave-on formulations at correct pH\n\n## The Bottom Line\n\nA preserved product with parabens is safer than an "all-natural" unpreserved one. Preservation is non-negotiable in any water-containing formula.` },
        { title: 'INCI Language: Reading a Formula Like a Pro', slug: 'inci-language', duration: 20,
          content: `# INCI Language: Reading a Formula\n\nINCl stands for International Nomenclature of Cosmetic Ingredients. It is the universal language of cosmetic formulation, adopted by the EU, Canada, and the US.\n\n## INCI Rules\n\n1. **Plant-derived ingredients:** Latin binomial name (genus + species) + plant part\n   - Example: Butyrospermum Parkii Butter = Shea Butter (fruit butter)\n2. **Synthetic/chemical ingredients:** IUPAC-derived name\n   - Example: Glycerin = Propane-1,2,3-triol\n3. **Order on label:** Descending concentration above 1%; below 1% may be listed in any order\n\n## Decoding a Label in 60 Seconds\n\n**Step 1:** First 5 ingredients = the bulk of the formula (usually >70% of the product)\n**Step 2:** Identify the base: water (Aqua), oil, or both (emulsion)\n**Step 3:** Find the actives: typically in the middle third\n**Step 4:** Check the end: fragrance, preservatives, colorants\n\n## Red Flags to Look For\n\n- **"Fragrance" / "Parfum"** high on the list: potential irritant/sensitiser\n- **No preservative listed** in an aqueous product: question formulation integrity\n- **Active ingredient last**: may be present below effective concentration\n\n## C-Ai INCI Integration\n\nEvery ingredient in the C-Ai database is catalogued by its full INCI name, common name, function, concentration range, and compatibility data. This lets the system generate a formula with an INCI-compliant ingredient list ready for label review.` },
      ],
    },
    {
      title: 'Tier III — Consultation Architecture', order: 3,
      lessons: [
        { title: 'The 7-Step Consultation System', slug: 'consultation-system', duration: 40,
          content: `# The 7-Step Consultation System\n\nThe Caryl Baker Visage methodology, refined over 20 years of professional practice. This is not a script — it is a framework for structured conversation that builds trust, extracts information, and closes through education.\n\n## The 7 Steps\n\n**Step 1: Welcome & Rapport**\nThe first 60 seconds determine the entire consultation. Greet by name. Make eye contact. Comment on something genuine. The goal is to make the client feel seen, not processed.\n\n**Step 2: Intake Review**\nReview their completed intake before touching their face. Know their history. Nothing destroys trust faster than asking a question already answered on the form.\n\n**Step 3: Skin Analysis**\nSystematic assessment: hydration, texture, pores, pigmentation, congestion, sensitivity, barrier integrity. Work in a consistent order. Use language that informs, not alarms.\n\n**Step 4: Education**\n*"This is what I'm seeing. Here's why it's happening."* Connect what the client sees in the mirror to the mechanism underneath. They came for a solution — give them the science behind it first.\n\n**Step 5: Create the Need**\nNot pressure. Not manipulation. The natural result of education. When a client understands that their barrier is compromised and that unaddressed barrier damage accelerates every skin concern they have — the need creates itself.\n\n**Step 6: Product Selection**\nPresent maximum 2–3 options. More is paralysis. Each recommendation connects directly back to what you identified in the analysis: "This serum addresses the hyperpigmentation we saw here, because…"\n\n**Step 7: Close + Commitment**\nBook the follow-up before they leave. Confirm the two-week check-in. Set an expectation of what they should see and when. A client with a roadmap is a client who comes back.` },
        { title: 'Intake Design: What to Ask and Why', slug: 'intake-design', duration: 30,
          content: `# Intake Design: What to Ask and Why\n\n## The Problem with Generic Intakes\n\nMost intake forms ask: "Do you have sensitive skin?" This is almost useless. The answer is almost always "no" — and almost always wrong.\n\n## The Forensic Approach\n\nThe intake should function like a medical history, not a preference survey. The goal is to surface information the client doesn't know is relevant.\n\n## The Five Intake Domains\n\n**1. Cumulative Exposure History**\n- What products have you used in the last 6 months?\n- Any prescriptions (tretinoin, antibiotics, Accutane)?\n- Any professional treatments?\n\n*Why it matters:* A client on tretinoin who doesn't mention it is a client who will react to the AHA you're about to recommend.\n\n**2. Reaction History**\n- Have you ever reacted to a product? What happened?\n- What was in it, as best you know?\n\n*Why it matters:* Cross-reactivity is real. A fragrance reaction predicts 40% likelihood of reaction to essential oils and some plant extracts.\n\n**3. Lifestyle Factors**\n- What does your water exposure look like? (swimming, hard water)\n- Sun exposure, geographic location?\n- Stress, sleep, diet — particularly dairy and high-glycaemic foods for acne clients\n\n**4. Goals vs. Concerns**\n- What bothers you the most right now?\n- What does improvement look like to you in 30 days? 90 days?\n\n*Why it matters:* Misaligned expectations are the #1 cause of unhappy clients. Establish them early.\n\n**5. Medical / Reproductive Status**\n- Pregnancy or breastfeeding (retinoids, salicylic acid, certain essential oils are contraindicated)\n- Autoimmune conditions (rosacea, psoriasis, lupus have skincare implications)\n- Photosensitising medications (some antidepressants, antibiotics, diuretics increase UV sensitivity)` },
        { title: 'Reading Skin Without a Woods Lamp', slug: 'reading-skin', duration: 35, content: '# Reading Skin Without a Woods Lamp\n\nThe visual analysis protocol for the C-Ai consultation system.' },
        { title: 'Creating the Need Without Pressure', slug: 'creating-need', duration: 28, content: '# Creating the Need Without Pressure\n\nEducation-first selling: the C-Ai methodology.' },
        { title: 'The 2-Week Check-In Protocol', slug: 'checkin-protocol', duration: 22, content: '# The 2-Week Check-In Protocol\n\nHow to structure the follow-up that builds lifetime clients.' },
        { title: 'Handling Objections with Science', slug: 'objections', duration: 25, content: '# Handling Objections with Science\n\nEvidence-based responses to the most common client concerns.' },
      ],
    },
    {
      title: 'Tier IV — Treatment Structuring', order: 4,
      lessons: [
        { title: 'Building the 6-Month Transformation Roadmap', slug: 'transformation-roadmap', duration: 42, content: '# The 6-Month Transformation Roadmap\n\nSequencing treatments for compounding results.' },
        { title: 'Treatment Sequencing by Concern', slug: 'treatment-sequencing', duration: 35, content: '# Treatment Sequencing by Concern\n\nAcne, pigmentation, aging, sensitivity — each requires a different sequence.' },
        { title: 'Layering Modalities: When & Why', slug: 'layering-modalities', duration: 30, content: '# Layering Modalities\n\nChemical, mechanical, energy-based — how to combine for maximum effect.' },
        { title: 'Managing Purging vs. Reaction', slug: 'purging-vs-reaction', duration: 25, content: '# Purging vs. Reaction\n\nThe most important clinical distinction for retinoid and AHA clients.' },
        { title: 'Seasonal Skin Adjustments', slug: 'seasonal-adjustments', duration: 20, content: '# Seasonal Skin Adjustments\n\nHow humidity, temperature, and UV index change the formula.' },
        { title: 'The Retention Formula', slug: 'retention-formula', duration: 28, content: '# The Retention Formula\n\nWhat turns a one-time client into a lifelong customer.' },
      ],
    },
    {
      title: 'Tier V — Brand Architecture', order: 5,
      lessons: [
        { title: 'Formulation-to-Market: The Lab Partner Process', slug: 'lab-partner-process', duration: 45, content: '# The Lab Partner Process\n\nFrom C-Ai formula to manufactured product.' },
        { title: 'Compliance: COSMOS, Health Canada, FDA Basics', slug: 'compliance-basics', duration: 40, content: '# Compliance Basics\n\nWhat every beauty professional needs to know about cosmetic regulation.' },
        { title: 'Pricing Your Line for Margin', slug: 'pricing-for-margin', duration: 30, content: '# Pricing for Margin\n\nCOGS, markup, and positioning your formulas for profitability.' },
        { title: 'White-Label vs. Custom Formulation', slug: 'whitelabel-vs-custom', duration: 25, content: '# White-Label vs. Custom\n\nWhen to choose each and how to evaluate lab partners.' },
        { title: 'Retail vs. Professional-Only Strategy', slug: 'retail-strategy', duration: 28, content: '# Retail vs. Professional Strategy\n\nChannel strategy for your product line.' },
        { title: 'Building Your Dispensary Model', slug: 'dispensary-model', duration: 35, content: '# The Dispensary Model\n\nHow to generate recurring revenue from your formula library.' },
      ],
    },
    {
      title: 'Tier VI — Revenue Architecture', order: 6,
      lessons: [
        { title: 'The Menu Architecture System', slug: 'menu-architecture', duration: 38, content: '# Menu Architecture\n\nDesigning your service menu for maximum perceived value and conversion.' },
        { title: 'Signature Treatment Development', slug: 'signature-treatment', duration: 45, content: '# Signature Treatment Development\n\nCreating proprietary treatments that cannot be replicated.' },
        { title: 'The Upsell Conversation', slug: 'upsell-conversation', duration: 30, content: '# The Upsell Conversation\n\nProduct recommendations that never feel like selling.' },
        { title: 'Building Recurring Revenue Streams', slug: 'recurring-revenue', duration: 35, content: '# Recurring Revenue\n\nMemberships, subscriptions, and loyalty architectures for beauty businesses.' },
        { title: 'Digital Revenue: Courses, Consultations, Content', slug: 'digital-revenue', duration: 32, content: '# Digital Revenue\n\nTurning your expertise into scalable income.' },
        { title: 'The Exit Strategy: Building Brand Equity', slug: 'brand-equity', duration: 28, content: '# Brand Equity\n\nBuilding a beauty business that has value beyond your presence.' },
      ],
    },
  ]

  for (const mod of MODULES) {
    const createdModule = await prisma.module.create({
      data: { courseId: ebos.id, title: mod.title, order: mod.order },
    })

    for (const [i, lesson] of mod.lessons.entries()) {
      await prisma.lesson.create({
        data: {
          moduleId:  createdModule.id,
          title:     lesson.title,
          slug:      lesson.slug,
          content:   lesson.content,
          duration:  lesson.duration,
          order:     i + 1,
          published: true,
        },
      })
    }
    console.log(`  ✅ Module: ${mod.title} (${mod.lessons.length} lessons)`)
  }

  // ─── SEED INGREDIENTS ─────────────────────────────────────────
  const ingredients = [
    { inci:'Aqua', commonName:'Purified Water', category:'SOLVENT', function:['Solvent','Hydration vehicle'], concentration:{min:40,max:85,typical:65,unit:'%'}, solubility:'water', skinTypes:['NORMAL','DRY','OILY','COMBINATION','SENSITIVE','MATURE'], concerns:[], cosmos:true, vegan:true, description:'The universal cosmetic solvent. All aqueous formulations begin here.', verified:true },
    { inci:'Glycerin', commonName:'Vegetable Glycerin', category:'HUMECTANT', function:['Humectant','Skin conditioner'], concentration:{min:2,max:10,typical:5,unit:'%'}, solubility:'water', skinTypes:['NORMAL','DRY','OILY','COMBINATION','SENSITIVE','MATURE'], concerns:['dehydration','texture'], cosmos:true, vegan:true, description:'The most well-studied humectant. Draws moisture from environment into skin. Optimal at 3–5%.', verified:true },
    { inci:'Sodium Hyaluronate', commonName:'Hyaluronic Acid', category:'HUMECTANT', function:['Humectant','Film-forming','Plumping'], concentration:{min:0.1,max:2,typical:0.5,unit:'%'}, solubility:'water', skinTypes:['NORMAL','DRY','OILY','COMBINATION','SENSITIVE','MATURE'], concerns:['dehydration','fine_lines'], cosmos:true, vegan:true, description:'Holds up to 6L of water per gram. Multi-weight versions target different skin depths.', verified:true },
    { inci:'Niacinamide', commonName:'Vitamin B3 / Niacinamide', category:'ACTIVE', function:['Brightening','Barrier support','Pore refinement','Anti-inflammatory'], concentration:{min:2,max:10,typical:5,unit:'%'}, solubility:'water', skinTypes:['OILY','COMBINATION','NORMAL','SENSITIVE'], concerns:['hyperpigmentation','enlarged_pores','dullness','texture'], cosmos:false, vegan:true, description:'Multi-tasking active. Inhibits NF-κB, reduces cytokines, strengthens barrier. Incompatible with Vitamin C (L-AA) in same formula.', verified:true, incompatible:['Ascorbic Acid'], hotlistCapped:false },
    { inci:'Ascorbic Acid', commonName:'Vitamin C (L-Ascorbic Acid)', category:'ANTIOXIDANT', function:['Brightening','Antioxidant','Collagen synthesis inhibits tyrosinase'], concentration:{min:10,max:20,typical:15,unit:'%'}, phRange:{min:2.5,max:3.5}, solubility:'water', skinTypes:['NORMAL','OILY','COMBINATION','MATURE'], concerns:['hyperpigmentation','dullness','antioxidant','fine_lines'], cosmos:false, vegan:true, description:'The gold-standard brightening active. Requires pH 2.5–3.5 for efficacy. Unstable — use airless packaging.', verified:true },
    { inci:'Retinol', commonName:'Retinol (Vitamin A)', category:'ACTIVE', function:['Cell turnover','Collagen stimulation','Anti-aging','Acne treatment'], concentration:{min:0.025,max:0.3,typical:0.1,unit:'%'}, solubility:'oil', skinTypes:['NORMAL','OILY','COMBINATION','MATURE'], concerns:['fine_lines','wrinkles','texture','acne_scarring'], cosmos:false, vegan:true, pregnancyFlag:true, hotlistCapped:true, hotlistMaxPct:0.3, description:'The most studied anti-aging active. PM use only. Build slowly (0.025% for 4 weeks before increasing). Incompatible with AHAs and BHAs.', verified:true },
    { inci:'Salicylic Acid', commonName:'Salicylic Acid (BHA)', category:'EXFOLIANT', function:['Oil-soluble exfoliant','Pore clearing','Anti-inflammatory'], concentration:{min:0.5,max:2,typical:1,unit:'%'}, phRange:{min:3.0,max:4.0}, solubility:'oil', skinTypes:['OILY','COMBINATION'], concerns:['enlarged_pores','texture','congestion'], cosmos:false, vegan:true, pregnancyFlag:true, hotlistCapped:true, hotlistMaxPct:2.0, description:'Lipophilic exfoliant that penetrates follicles. Health Canada Hotlist max 2% in leave-on products.', verified:true },
    { inci:'Glycolic Acid', commonName:'Glycolic Acid (AHA)', category:'EXFOLIANT', function:['Chemical exfoliation','Brightening','Texture refinement'], concentration:{min:2,max:10,typical:5,unit:'%'}, phRange:{min:3.0,max:4.5}, solubility:'water', skinTypes:['NORMAL','OILY','COMBINATION','MATURE'], concerns:['texture','dullness','hyperpigmentation','fine_lines'], cosmos:false, vegan:true, description:'Smallest AHA, greatest penetration. Most effective at 5–10% and pH 3.0–4.0. Increases UV sensitivity — always pair with SPF.', verified:true },
    { inci:'Ceramide NP', commonName:'Ceramide', category:'EMOLLIENT', function:['Barrier repair','Lipid replenishment','Moisture retention'], concentration:{min:0.5,max:3,typical:1,unit:'%'}, solubility:'oil', skinTypes:['DRY','SENSITIVE','MATURE'], concerns:['barrier_damage','sensitivity','dryness'], cosmos:false, vegan:true, description:'Key structural lipid of the stratum corneum. Replenishes barrier lipid matrix. Works synergistically with cholesterol and fatty acids.', verified:true },
    { inci:'Squalane', commonName:'Plant-Derived Squalane', category:'EMOLLIENT', function:['Emollient','Barrier support','Non-comedogenic carrier'], concentration:{min:1,max:10,typical:4,unit:'%'}, solubility:'oil', skinTypes:['NORMAL','DRY','OILY','COMBINATION','SENSITIVE','MATURE'], concerns:['dryness','barrier_damage'], cosmos:true, vegan:true, description:'Derived from sugarcane. Mimics sebum composition. Exceptional tolerance profile. Non-comedogenic.', verified:true },
    { inci:'Butyrospermum Parkii Butter', commonName:'Shea Butter', category:'EMOLLIENT', function:['Rich emollient','Occlusive','Anti-inflammatory'], concentration:{min:2,max:15,typical:6,unit:'%'}, solubility:'oil', skinTypes:['DRY','MATURE','SENSITIVE'], concerns:['dryness','barrier_damage'], cosmos:true, vegan:true, description:'Rich in oleic and stearic acids. Contains triterpenes with anti-inflammatory activity. COSMOS-approved.', verified:true },
    { inci:'Panthenol', commonName:'Pro-Vitamin B5', category:'HUMECTANT', function:['Humectant','Wound healing','Anti-inflammatory'], concentration:{min:0.5,max:5,typical:2,unit:'%'}, solubility:'water', skinTypes:['NORMAL','DRY','OILY','COMBINATION','SENSITIVE','MATURE'], concerns:['barrier_damage','sensitivity','dehydration'], cosmos:true, vegan:true, description:'Converts to pantothenic acid in skin. Accelerates wound healing, reduces inflammation. Safe for all skin types.', verified:true },
    { inci:'Allantoin', commonName:'Allantoin', category:'ACTIVE', function:['Soothing','Cell proliferation stimulant','Mild keratolytic'], concentration:{min:0.1,max:0.5,typical:0.2,unit:'%'}, solubility:'water', skinTypes:['SENSITIVE','DRY','NORMAL'], concerns:['sensitivity','redness','texture'], cosmos:true, vegan:true, description:'Stimulates cell proliferation and wound healing at low concentrations. COSMOS-approved. Excellent tolerance.', verified:true },
    { inci:'Centella Asiatica Extract', commonName:'Cica / Centella', category:'ACTIVE', function:['Wound healing','Calming','Barrier strengthening','Collagen support'], concentration:{min:0.5,max:5,typical:1,unit:'%'}, solubility:'water', skinTypes:['SENSITIVE','DRY','NORMAL'], concerns:['sensitivity','redness','barrier_damage'], cosmos:true, vegan:true, description:'Asiaticoside stimulates collagen. Madecassic acid suppresses inflammatory cytokines. Ideal for rosacea and post-treatment skin.', verified:true },
    { inci:'Tocopherol', commonName:'Vitamin E', category:'ANTIOXIDANT', function:['Antioxidant','Skin conditioning','Formula stabiliser'], concentration:{min:0.1,max:1,typical:0.5,unit:'%'}, solubility:'oil', skinTypes:['NORMAL','DRY','OILY','COMBINATION','SENSITIVE','MATURE'], concerns:['antioxidant','aging'], cosmos:true, vegan:true, description:'Oil-soluble antioxidant. Scavenges free radicals, prevents lipid peroxidation in the formula and on skin.', verified:true },
    { inci:'Phenoxyethanol', commonName:'Phenoxyethanol', category:'PRESERVATIVE', function:['Broad-spectrum preservative'], concentration:{min:0.5,max:1,typical:0.9,unit:'%'}, solubility:'both', skinTypes:['NORMAL','DRY','OILY','COMBINATION','SENSITIVE','MATURE'], concerns:[], cosmos:false, vegan:true, hotlistCapped:true, hotlistMaxPct:1.0, description:'Well-tolerated broad-spectrum preservative. Health Canada Hotlist maximum 1.0%. Not COSMOS-approved.', verified:true },
    { inci:'Ethylhexylglycerin', commonName:'Ethylhexylglycerin', category:'PRESERVATIVE', function:['Preservative booster','Skin conditioning'], concentration:{min:0.1,max:0.5,typical:0.3,unit:'%'}, solubility:'both', skinTypes:['NORMAL','DRY','OILY','COMBINATION','SENSITIVE','MATURE'], concerns:[], cosmos:false, vegan:true, description:'Commonly paired with phenoxyethanol for synergistic preservative effect. Skin conditioning at low concentrations.', verified:true },
    { inci:'Xanthan Gum', commonName:'Xanthan Gum', category:'THICKENER', function:['Viscosity builder','Emulsion stabiliser'], concentration:{min:0.1,max:0.8,typical:0.3,unit:'%'}, solubility:'water', skinTypes:['NORMAL','DRY','OILY','COMBINATION','SENSITIVE','MATURE'], concerns:[], cosmos:true, vegan:true, description:'Naturally fermented polysaccharide. Builds viscosity in water phase. COSMOS-approved.', verified:true },
    { inci:'Cetearyl Olivate (and) Sorbitan Olivate', commonName:'Olivem 1000', category:'EMULSIFIER', function:['O/W emulsifier','Skin lipid mimic'], concentration:{min:3,max:8,typical:5,unit:'%'}, solubility:'oil', skinTypes:['NORMAL','DRY','OILY','COMBINATION','SENSITIVE','MATURE'], concerns:[], cosmos:true, vegan:true, description:'COSMOS-approved olive-derived emulsifier. Lamellar structure mimics skin lipid organisation. Enhances skin feel and delivery.', verified:true },
    { inci:'Palmitoyl Tripeptide-1', commonName:'Matrixyl (Peptide)', category:'PEPTIDE', function:['Collagen stimulation','Wrinkle reduction','Firming'], concentration:{min:0.01,max:0.1,typical:0.05,unit:'%'}, solubility:'water', skinTypes:['MATURE','NORMAL','DRY'], concerns:['fine_lines','wrinkles','firmness'], cosmos:false, vegan:false, description:'Signal peptide that activates collagen synthesis via TGF-β pathway. Most studied cosmetic peptide. Clinically shown to reduce wrinkle depth at 0.05–0.1%.', verified:true },
    { inci:'Zinc Oxide', commonName:'Zinc Oxide (Mineral SPF)', category:'ACTIVE', function:['Broad-spectrum UVA/UVB filter','Anti-inflammatory'], concentration:{min:5,max:25,typical:15,unit:'%'}, solubility:'oil', skinTypes:['NORMAL','DRY','OILY','COMBINATION','SENSITIVE','MATURE'], concerns:[], cosmos:true, vegan:true, nhpPathway:true, description:'Physical UV filter. NHP pathway required in Canada for SPF claims. COSMOS-approved. Only safe UV filter for pregnancy.', verified:true },
  ]

  for (const ing of ingredients) {
    await prisma.ingredient.upsert({
      where:  { inci: ing.inci },
      update: {},
      create: {
        inci:         ing.inci,
        commonName:   ing.commonName,
        category:     ing.category as any,
        function:     ing.function,
        concentration: ing.concentration,
        phRange:      (ing as any).phRange ?? null,
        solubility:   ing.solubility,
        skinTypes:    ing.skinTypes,
        concerns:     ing.concerns,
        incompatible: (ing as any).incompatible ?? [],
        cosmos:       ing.cosmos,
        vegan:        ing.vegan,
        pregnancyFlag: (ing as any).pregnancyFlag ?? false,
        medicalFlag:  false,
        hotlistCapped: (ing as any).hotlistCapped ?? false,
        hotlistMaxPct: (ing as any).hotlistMaxPct ?? null,
        description:  ing.description,
        verified:     ing.verified,
        verifiedAt:   new Date(),
      },
    })
  }
  console.log(`✅ ${ingredients.length} ingredients seeded`)
  console.log('\n🚀 Database seeded successfully!')
  console.log('\nYour admin login:')
  console.log('  Email:    admin@ambitiouslyinstitute.com')
  console.log('  Password: (set ADMIN_PASSWORD env var, default: admin-change-me)')
  console.log('\nCHANGE THE ADMIN PASSWORD IMMEDIATELY IN PRODUCTION.')
}

main()
  .catch(e => { console.error(e); process.exit(1) })
  .finally(() => prisma.$disconnect())
