# Ambitiously Institute + C-Ai
## Production Deployment Guide

---

## What's in this build

| Layer | What's built |
|---|---|
| Database | Prisma schema: users, subscriptions, intakes, formulas, courses, ingredients, orders |
| Auth | NextAuth: credentials + magic link, JWT, role-based (CONSUMER/PRO/ADMIN) |
| Payments | Stripe: 6 plans, checkout sessions, webhook handler, billing portal |
| C-Ai Engine | Formulation rules engine: 20+ ingredients, incompatibility matrix, Health Canada hotlist, COSMOS/pregnancy filters |
| PDF Generation | Consumer reports + Pro Lab Pack PDFs (pdf-lib) |
| AI Analysis | Anthropic Vision: skin photo analysis, structured JSON output |
| Frontend | 10+ pages: home, pricing, auth, wizard, results, dashboard, academy, admin |

---

## Step 1 — Database (Supabase — recommended)

1. Go to [supabase.com](https://supabase.com) → New project
2. Copy your **Database URL** (Settings → Database → Connection string → URI)
3. Replace `[YOUR-PASSWORD]` with your DB password

---

## Step 2 — Stripe Setup

1. **Create products** in [dashboard.stripe.com](https://dashboard.stripe.com):

| Product | Price | Mode |
|---|---|---|
| Skin Report | $47 | one-time |
| C-Ai Member | $97/mo | subscription |
| Pro Starter | $97/mo | subscription |
| Pro Unlimited | $197/mo | subscription |
| EBOS Program | $497 | one-time |
| EBOS Elite | $997 | one-time |

2. Copy each **Price ID** (starts with `price_`)
3. Set up **Webhook** → `https://yourdomain.com/api/webhooks/stripe`
   - Events: `checkout.session.completed`, `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`, `invoice.payment_failed`
4. Copy **Webhook signing secret** (`whsec_...`)

---

## Step 3 — Environment Variables

Copy `.env.example` → `.env.local` and fill in all values:

```bash
DATABASE_URL="postgresql://..."
NEXTAUTH_URL="https://ambitiouslyinstitute.com"
NEXTAUTH_SECRET="$(openssl rand -base64 32)"
ANTHROPIC_API_KEY="sk-ant-..."
STRIPE_SECRET_KEY="sk_live_..."
STRIPE_WEBHOOK_SECRET="whsec_..."
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY="pk_live_..."
STRIPE_PRICE_CONSUMER_BASIC="price_..."
STRIPE_PRICE_CONSUMER_PRO="price_..."
STRIPE_PRICE_PRO_STARTER="price_..."
STRIPE_PRICE_PRO_UNLIMITED="price_..."
STRIPE_PRICE_EBOS_COURSE="price_..."
STRIPE_PRICE_EBOS_ELITE="price_..."
EMAIL_SERVER_HOST="smtp.resend.com"
EMAIL_SERVER_PORT="465"
EMAIL_SERVER_USER="resend"
EMAIL_SERVER_PASSWORD="re_..."
EMAIL_FROM="hello@ambitiouslyinstitute.com"
NEXT_PUBLIC_APP_URL="https://ambitiouslyinstitute.com"
```

---

## Step 4 — Deploy to Netlify

1. Push this repo to GitHub
2. In Netlify → **Add new site** → **Import from GitHub**
3. Build settings:
   - **Build command:** `npx prisma generate && next build`
   - **Publish directory:** `.next`
4. Add all environment variables in Netlify → Site Settings → Environment Variables
5. Add **Netlify Next.js plugin**: `npm install -D @netlify/plugin-nextjs`
6. Create `netlify.toml`:
```toml
[build]
  command = "npx prisma generate && next build"
  publish = ".next"

[[plugins]]
  package = "@netlify/plugin-nextjs"
```

---

## Step 5 — Run DB Migration

After deploying, run once via Supabase SQL editor or local terminal:
```bash
npx prisma db push
```

---

## Step 6 — Create First Admin User

In Supabase SQL editor:
```sql
UPDATE "User" SET role = 'ADMIN' WHERE email = 'your@email.com';
```

---

## Make Conrad the First Admin

Register at `/auth/register`, then run the SQL above with your email.
Go to `/admin` — your full platform dashboard.

---

## Revenue Streams — Live Immediately

| Stream | URL | Revenue |
|---|---|---|
| C-Ai Consumer Analysis | `/start` | $47–$97/mo |
| Pro Lab Packs | `/pricing#pro` | $97–$197/mo |
| EBOS Education | `/academy` | $497–$997 |

---

## Domain Setup

- `ambitiouslyinstitute.com` → Netlify site (main app)
- `c-ai.ambitiouslyinstitute.com` → Same site or separate deployment

In Netlify: Domain Management → Add custom domain.
